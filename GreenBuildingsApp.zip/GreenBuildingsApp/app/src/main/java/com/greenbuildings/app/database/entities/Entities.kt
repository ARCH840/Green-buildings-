package com.greenbuildings.app.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.util.Date

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true)
    val userId: Long = 0,
    val username: String,
    val password: String,
    val createdAt: Date,
    val lastLogin: Date?
)

@Entity(tableName = "buildings")
data class Building(
    @PrimaryKey(autoGenerate = true)
    val buildingId: Long = 0,
    val name: String,
    val address: String,
    val totalApartments: Int,
    val availableApartments: Int,
    val logoPath: String?,
    val createdAt: Date,
    val updatedAt: Date
)

@Entity(tableName = "apartments")
data class Apartment(
    @PrimaryKey(autoGenerate = true)
    val apartmentId: Long = 0,
    val buildingId: Long,
    val name: String,
    val floor: String,
    val area: Double,
    val pricePerMeter: Double,
    val totalPrice: Double,
    val currency: String,
    val status: String, // "available" or "sold"
    val imagePath: String?,
    val createdAt: Date,
    val updatedAt: Date
)

@Entity(tableName = "buyers")
data class Buyer(
    @PrimaryKey(autoGenerate = true)
    val buyerId: Long = 0,
    val name: String,
    val phone: String,
    val idImagePath: String?,
    val createdAt: Date,
    val updatedAt: Date
)

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true)
    val saleId: Long = 0,
    val apartmentId: Long,
    val buyerId: Long,
    val saleDate: Date,
    val totalAmount: Double,
    val paymentType: String, // "cash" or "installments"
    val downPaymentPercentage: Double?,
    val downPaymentAmount: Double?,
    val downPaymentDate: Date?,
    val downPaymentStatus: String?, // "paid" or "unpaid"
    val downPaymentReceiptPath: String?,
    val remainingAmount: Double?,
    val installmentType: String?, // "free" or "scheduled"
    val installmentPeriod: Int?, // in months
    val installmentFrequency: String?, // "monthly", "bimonthly", "quarterly", "biannually"
    val createdAt: Date,
    val updatedAt: Date
)

@Entity(tableName = "installments")
data class Installment(
    @PrimaryKey(autoGenerate = true)
    val installmentId: Long = 0,
    val saleId: Long,
    val amount: Double,
    val dueDate: Date,
    val status: String, // "due", "paid", "late"
    val paidAmount: Double?,
    val remainingAmount: Double?,
    val paymentDate: Date?,
    val receiptPath: String?,
    val nextPaymentDate: Date?,
    val notes: String?,
    val createdAt: Date,
    val updatedAt: Date
)

@Entity(tableName = "receipts")
data class Receipt(
    @PrimaryKey(autoGenerate = true)
    val receiptId: Long = 0,
    val saleId: Long,
    val installmentId: Long?,
    val amount: Double,
    val paymentDate: Date,
    val receiptNumber: String,
    val receiptPath: String?,
    val createdAt: Date
)

@Entity(tableName = "notifications")
data class Notification(
    @PrimaryKey(autoGenerate = true)
    val notificationId: Long = 0,
    val installmentId: Long,
    val notificationDate: Date,
    val status: String, // "new" or "read"
    val type: String, // "due_installment" or "late_payment"
    val createdAt: Date
)
