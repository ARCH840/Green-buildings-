package com.greenbuildings.app.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.greenbuildings.app.database.dao.*
import com.greenbuildings.app.database.entities.*
import com.greenbuildings.app.database.utils.DateConverter

@Database(
    entities = [
        User::class,
        Building::class,
        Apartment::class,
        Buyer::class,
        Sale::class,
        Installment::class,
        Receipt::class,
        Notification::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(DateConverter::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun buildingDao(): BuildingDao
    abstract fun apartmentDao(): ApartmentDao
    abstract fun buyerDao(): BuyerDao
    abstract fun saleDao(): SaleDao
    abstract fun installmentDao(): InstallmentDao
    abstract fun receiptDao(): ReceiptDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "green_buildings_database"
                )
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
