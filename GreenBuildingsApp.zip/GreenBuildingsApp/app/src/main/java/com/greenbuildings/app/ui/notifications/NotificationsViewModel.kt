package com.greenbuildings.app.ui.notifications

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.greenbuildings.app.database.entities.Notification
import com.greenbuildings.app.repository.NotificationRepository
import kotlinx.coroutines.launch

class NotificationsViewModel(
    private val notificationRepository: NotificationRepository
) : ViewModel() {
    
    private val _notifications = MutableLiveData<List<Notification>>()
    val notifications: LiveData<List<Notification>> = _notifications
    
    private val _state = MutableLiveData<NotificationsState>()
    val state: LiveData<NotificationsState> = _state
    
    init {
        loadNotifications()
    }
    
    fun loadNotifications() {
        viewModelScope.launch {
            try {
                _state.value = NotificationsState.Loading
                val notificationsList = notificationRepository.getAllNotifications()
                _notifications.value = notificationsList
                _state.value = NotificationsState.Success
            } catch (e: Exception) {
                _state.value = NotificationsState.Error("حدث خطأ أثناء تحميل التنبيهات: ${e.message}")
            }
        }
    }
    
    fun markNotificationAsRead(notificationId: Long) {
        viewModelScope.launch {
            try {
                notificationRepository.markNotificationAsRead(notificationId)
                loadNotifications()
            } catch (e: Exception) {
                // Log error
            }
        }
    }
}

sealed class NotificationsState {
    object Loading : NotificationsState()
    object Success : NotificationsState()
    data class Error(val message: String) : NotificationsState()
}
