package com.greenbuildings.app.ui.buildings

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.greenbuildings.app.database.entities.Building
import com.greenbuildings.app.repository.BuildingRepository
import kotlinx.coroutines.launch
import java.io.File

class BuildingsViewModel(private val buildingRepository: BuildingRepository) : ViewModel() {
    
    private val _buildings = MutableLiveData<List<Building>>()
    val buildings: LiveData<List<Building>> = _buildings
    
    private val _state = MutableLiveData<BuildingsState>()
    val state: LiveData<BuildingsState> = _state
    
    init {
        loadBuildings()
    }
    
    fun loadBuildings() {
        viewModelScope.launch {
            try {
                _state.value = BuildingsState.Loading
                val buildingsList = buildingRepository.getAllBuildings()
                _buildings.value = buildingsList
                _state.value = BuildingsState.Success
            } catch (e: Exception) {
                _state.value = BuildingsState.Error("حدث خطأ أثناء تحميل الأبراج: ${e.message}")
            }
        }
    }
    
    fun addBuilding(name: String, address: String, totalApartments: Int, logoPath: String?) {
        viewModelScope.launch {
            try {
                _state.value = BuildingsState.Loading
                buildingRepository.insertBuilding(name, address, totalApartments, logoPath)
                loadBuildings()
                _state.value = BuildingsState.Success
            } catch (e: Exception) {
                _state.value = BuildingsState.Error("حدث خطأ أثناء إضافة البرج: ${e.message}")
            }
        }
    }
    
    fun updateBuilding(building: Building) {
        viewModelScope.launch {
            try {
                _state.value = BuildingsState.Loading
                buildingRepository.updateBuilding(building)
                loadBuildings()
                _state.value = BuildingsState.Success
            } catch (e: Exception) {
                _state.value = BuildingsState.Error("حدث خطأ أثناء تحديث البرج: ${e.message}")
            }
        }
    }
    
    fun deleteBuilding(building: Building) {
        viewModelScope.launch {
            try {
                _state.value = BuildingsState.Loading
                
                // Delete building logo if exists
                building.logoPath?.let { path ->
                    val logoFile = File(path)
                    if (logoFile.exists()) {
                        logoFile.delete()
                    }
                }
                
                buildingRepository.deleteBuilding(building)
                loadBuildings()
                _state.value = BuildingsState.Success
            } catch (e: Exception) {
                _state.value = BuildingsState.Error("حدث خطأ أثناء حذف البرج: ${e.message}")
            }
        }
    }
}

sealed class BuildingsState {
    object Loading : BuildingsState()
    object Success : BuildingsState()
    data class Error(val message: String) : BuildingsState()
}
