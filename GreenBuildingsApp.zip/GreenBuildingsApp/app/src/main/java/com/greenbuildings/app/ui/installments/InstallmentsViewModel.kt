package com.greenbuildings.app.ui.installments

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.greenbuildings.app.database.entities.Installment
import com.greenbuildings.app.database.entities.Receipt
import com.greenbuildings.app.database.entities.Sale
import com.greenbuildings.app.repository.InstallmentRepository
import com.greenbuildings.app.repository.ReceiptRepository
import com.greenbuildings.app.repository.SaleRepository
import kotlinx.coroutines.launch
import java.util.Date

class InstallmentsViewModel(
    private val installmentRepository: InstallmentRepository,
    private val saleRepository: SaleRepository,
    private val receiptRepository: ReceiptRepository
) : ViewModel() {
    
    private val _installments = MutableLiveData<List<Installment>>()
    val installments: LiveData<List<Installment>> = _installments
    
    private val _currentInstallment = MutableLiveData<Installment>()
    val currentInstallment: LiveData<Installment> = _currentInstallment
    
    private val _receipts = MutableLiveData<List<Receipt>>()
    val receipts: LiveData<List<Receipt>> = _receipts
    
    private val _sale = MutableLiveData<Sale>()
    val sale: LiveData<Sale> = _sale
    
    private val _state = MutableLiveData<InstallmentsState>()
    val state: LiveData<InstallmentsState> = _state
    
    fun loadInstallmentsBySale(saleId: Long) {
        viewModelScope.launch {
            try {
                _state.value = InstallmentsState.Loading
                val installmentsList = installmentRepository.getInstallmentsBySaleId(saleId)
                _installments.value = installmentsList
                
                // Load sale details
                val saleDetails = saleRepository.getSaleById(saleId)
                if (saleDetails != null) {
                    _sale.value = saleDetails
                }
                
                _state.value = InstallmentsState.Success
            } catch (e: Exception) {
                _state.value = InstallmentsState.Error("حدث خطأ أثناء تحميل الأقساط: ${e.message}")
            }
        }
    }
    
    fun getInstallmentById(installmentId: Long) {
        viewModelScope.launch {
            try {
                _state.value = InstallmentsState.Loading
                val installment = installmentRepository.getInstallmentById(installmentId)
                if (installment != null) {
                    _currentInstallment.value = installment
                    
                    // Load receipts for this installment
                    val receiptsList = receiptRepository.getReceiptsByInstallmentId(installmentId)
                    _receipts.value = receiptsList
                    
                    _state.value = InstallmentsState.Success
                } else {
                    _state.value = InstallmentsState.Error("لم يتم العثور على القسط")
                }
            } catch (e: Exception) {
                _state.value = InstallmentsState.Error("حدث خطأ أثناء تحميل بيانات القسط: ${e.message}")
            }
        }
    }
    
    fun recordFullPayment(
        installmentId: Long,
        saleId: Long,
        paymentDate: Date,
        receiptPath: String?
    ) {
        viewModelScope.launch {
            try {
                _state.value = InstallmentsState.Loading
                
                // Get installment details
                val installment = installmentRepository.getInstallmentById(installmentId)
                    ?: throw IllegalArgumentException("القسط غير موجود")
                
                // Mark installment as paid
                installmentRepository.markInstallmentAsPaid(
                    installmentId = installmentId,
                    paymentDate = paymentDate,
                    receiptPath = receiptPath
                )
                
                // Generate receipt number (using timestamp for simplicity)
                val receiptNumber = "REC-${System.currentTimeMillis()}"
                
                // Create receipt
                installmentRepository.createReceipt(
                    saleId = saleId,
                    installmentId = installmentId,
                    amount = installment.amount,
                    paymentDate = paymentDate,
                    receiptNumber = receiptNumber,
                    receiptPath = receiptPath
                )
                
                // Refresh installment data
                getInstallmentById(installmentId)
                loadInstallmentsBySale(saleId)
                
                _state.value = InstallmentsState.Success
            } catch (e: Exception) {
                _state.value = InstallmentsState.Error("حدث خطأ أثناء تسجيل الدفع: ${e.message}")
            }
        }
    }
    
    fun recordPartialPayment(
        installmentId: Long,
        saleId: Long,
        paidAmount: Double,
        paymentDate: Date,
        nextPaymentDate: Date,
        receiptPath: String?
    ) {
        viewModelScope.launch {
            try {
                _state.value = InstallmentsState.Loading
                
                // Get installment details
                val installment = installmentRepository.getInstallmentById(installmentId)
                    ?: throw IllegalArgumentException("القسط غير موجود")
                
                // Update installment with partial payment
                installmentRepository.updatePartialPayment(
                    installmentId = installmentId,
                    paidAmount = paidAmount,
                    paymentDate = paymentDate,
                    nextPaymentDate = nextPaymentDate
                )
                
                // Generate receipt number (using timestamp for simplicity)
                val receiptNumber = "REC-${System.currentTimeMillis()}"
                
                // Create receipt
                installmentRepository.createReceipt(
                    saleId = saleId,
                    installmentId = installmentId,
                    amount = paidAmount,
                    paymentDate = paymentDate,
                    receiptNumber = receiptNumber,
                    receiptPath = receiptPath
                )
                
                // Refresh installment data
                getInstallmentById(installmentId)
                loadInstallmentsBySale(saleId)
                
                _state.value = InstallmentsState.Success
            } catch (e: Exception) {
                _state.value = InstallmentsState.Error("حدث خطأ أثناء تسجيل الدفع الجزئي: ${e.message}")
            }
        }
    }
    
    fun addInstallment(
        saleId: Long,
        amount: Double,
        dueDate: Date
    ) {
        viewModelScope.launch {
            try {
                _state.value = InstallmentsState.Loading
                
                // Create new installment
                installmentRepository.insertInstallment(
                    saleId = saleId,
                    amount = amount,
                    dueDate = dueDate
                )
                
                // Refresh installments list
                loadInstallmentsBySale(saleId)
                
                _state.value = InstallmentsState.Success
            } catch (e: Exception) {
                _state.value = InstallmentsState.Error("حدث خطأ أثناء إضافة القسط: ${e.message}")
            }
        }
    }
}

sealed class InstallmentsState {
    object Loading : InstallmentsState()
    object Success : InstallmentsState()
    data class Error(val message: String) : InstallmentsState()
}
