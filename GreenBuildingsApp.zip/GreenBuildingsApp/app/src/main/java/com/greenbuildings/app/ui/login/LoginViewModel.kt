package com.greenbuildings.app.ui.login

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.greenbuildings.app.repository.UserRepository
import kotlinx.coroutines.launch

class LoginViewModel(private val userRepository: UserRepository) : ViewModel() {
    
    private val _loginState = MutableLiveData<LoginState>()
    val loginState: LiveData<LoginState> = _loginState
    
    fun login(username: String, password: String) {
        viewModelScope.launch {
            _loginState.value = LoginState.Loading
            
            try {
                val user = userRepository.getUserByUsername(username)
                
                if (user != null && user.password == password) {
                    // Update last login time
                    userRepository.updateLastLogin(user.userId)
                    
                    // Save login state to shared preferences
                    _loginState.value = LoginState.Success(user.userId)
                } else {
                    _loginState.value = LoginState.Error("اسم المستخدم أو كلمة المرور غير صحيحة")
                }
            } catch (e: Exception) {
                _loginState.value = LoginState.Error("حدث خطأ أثناء تسجيل الدخول: ${e.message}")
            }
        }
    }
    
    fun createInitialUserIfNeeded(context: Context) {
        viewModelScope.launch {
            try {
                val sharedPreferences = context.getSharedPreferences("green_buildings_prefs", Context.MODE_PRIVATE)
                val isFirstRun = sharedPreferences.getBoolean("is_first_run", true)
                
                if (isFirstRun) {
                    // Create default admin user
                    val adminUser = userRepository.getUserByUsername("admin")
                    
                    if (adminUser == null) {
                        userRepository.insertUser("admin", "admin123")
                    }
                    
                    // Mark first run as completed
                    sharedPreferences.edit().putBoolean("is_first_run", false).apply()
                }
            } catch (e: Exception) {
                // Log error
            }
        }
    }
}

sealed class LoginState {
    object Loading : LoginState()
    data class Success(val userId: Long) : LoginState()
    data class Error(val message: String) : LoginState()
}
