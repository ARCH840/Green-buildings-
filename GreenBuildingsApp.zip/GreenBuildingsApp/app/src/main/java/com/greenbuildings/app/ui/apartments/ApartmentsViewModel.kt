package com.greenbuildings.app.ui.apartments

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.greenbuildings.app.database.entities.Apartment
import com.greenbuildings.app.repository.ApartmentRepository
import kotlinx.coroutines.launch
import java.io.File

class ApartmentsViewModel(
    private val apartmentRepository: ApartmentRepository
) : ViewModel() {
    
    private val _apartments = MutableLiveData<List<Apartment>>()
    val apartments: LiveData<List<Apartment>> = _apartments
    
    private val _availableApartments = MutableLiveData<List<Apartment>>()
    val availableApartments: LiveData<List<Apartment>> = _availableApartments
    
    private val _state = MutableLiveData<ApartmentsState>()
    val state: LiveData<ApartmentsState> = _state
    
    fun loadApartmentsByBuilding(buildingId: Long) {
        viewModelScope.launch {
            try {
                _state.value = ApartmentsState.Loading
                val apartmentsList = apartmentRepository.getApartmentsByBuilding(buildingId)
                _apartments.value = apartmentsList
                _state.value = ApartmentsState.Success
            } catch (e: Exception) {
                _state.value = ApartmentsState.Error("حدث خطأ أثناء تحميل الشقق: ${e.message}")
            }
        }
    }
    
    fun loadAvailableApartmentsByBuilding(buildingId: Long) {
        viewModelScope.launch {
            try {
                _state.value = ApartmentsState.Loading
                val availableApartmentsList = apartmentRepository.getAvailableApartmentsByBuilding(buildingId)
                _availableApartments.value = availableApartmentsList
                _state.value = ApartmentsState.Success
            } catch (e: Exception) {
                _state.value = ApartmentsState.Error("حدث خطأ أثناء تحميل الشقق المتاحة: ${e.message}")
            }
        }
    }
    
    fun addApartment(
        buildingId: Long,
        name: String,
        floor: String,
        area: Double,
        pricePerMeter: Double,
        currency: String,
        imagePath: String?
    ) {
        viewModelScope.launch {
            try {
                _state.value = ApartmentsState.Loading
                apartmentRepository.insertApartment(
                    buildingId = buildingId,
                    name = name,
                    floor = floor,
                    area = area,
                    pricePerMeter = pricePerMeter,
                    currency = currency,
                    imagePath = imagePath
                )
                loadApartmentsByBuilding(buildingId)
                loadAvailableApartmentsByBuilding(buildingId)
                _state.value = ApartmentsState.Success
            } catch (e: Exception) {
                _state.value = ApartmentsState.Error("حدث خطأ أثناء إضافة الشقة: ${e.message}")
            }
        }
    }
    
    fun updateApartment(apartment: Apartment) {
        viewModelScope.launch {
            try {
                _state.value = ApartmentsState.Loading
                apartmentRepository.updateApartment(apartment)
                loadApartmentsByBuilding(apartment.buildingId)
                loadAvailableApartmentsByBuilding(apartment.buildingId)
                _state.value = ApartmentsState.Success
            } catch (e: Exception) {
                _state.value = ApartmentsState.Error("حدث خطأ أثناء تحديث الشقة: ${e.message}")
            }
        }
    }
    
    fun deleteApartment(apartment: Apartment) {
        viewModelScope.launch {
            try {
                _state.value = ApartmentsState.Loading
                
                // Delete apartment image if exists
                apartment.imagePath?.let { path ->
                    val imageFile = File(path)
                    if (imageFile.exists()) {
                        imageFile.delete()
                    }
                }
                
                apartmentRepository.deleteApartment(apartment)
                loadApartmentsByBuilding(apartment.buildingId)
                loadAvailableApartmentsByBuilding(apartment.buildingId)
                _state.value = ApartmentsState.Success
            } catch (e: Exception) {
                _state.value = ApartmentsState.Error("حدث خطأ أثناء حذف الشقة: ${e.message}")
            }
        }
    }
    
    fun markApartmentAsSold(apartmentId: Long, buildingId: Long) {
        viewModelScope.launch {
            try {
                _state.value = ApartmentsState.Loading
                apartmentRepository.markApartmentAsSold(apartmentId)
                loadApartmentsByBuilding(buildingId)
                loadAvailableApartmentsByBuilding(buildingId)
                _state.value = ApartmentsState.Success
            } catch (e: Exception) {
                _state.value = ApartmentsState.Error("حدث خطأ أثناء تحديث حالة الشقة: ${e.message}")
            }
        }
    }
}

sealed class ApartmentsState {
    object Loading : ApartmentsState()
    object Success : ApartmentsState()
    data class Error(val message: String) : ApartmentsState()
}
