package com.greenbuildings.app.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.greenbuildings.app.database.entities.Building
import com.greenbuildings.app.repository.BuildingRepository
import com.greenbuildings.app.repository.InstallmentRepository
import com.greenbuildings.app.repository.NotificationRepository
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Date

class HomeViewModel(
    private val buildingRepository: BuildingRepository,
    private val installmentRepository: InstallmentRepository,
    private val notificationRepository: NotificationRepository
) : ViewModel() {
    
    private val _buildings = MutableLiveData<List<Building>>()
    val buildings: LiveData<List<Building>> = _buildings
    
    private val _notificationsCount = MutableLiveData<Int>()
    val notificationsCount: LiveData<Int> = _notificationsCount
    
    private val _state = MutableLiveData<HomeState>()
    val state: LiveData<HomeState> = _state
    
    init {
        loadBuildings()
        loadNotificationsCount()
        checkDueInstallments()
    }
    
    private fun loadBuildings() {
        viewModelScope.launch {
            try {
                _state.value = HomeState.Loading
                val buildingsList = buildingRepository.getAllBuildings()
                _buildings.value = buildingsList
                _state.value = HomeState.Success
            } catch (e: Exception) {
                _state.value = HomeState.Error("حدث خطأ أثناء تحميل الأبراج: ${e.message}")
            }
        }
    }
    
    private fun loadNotificationsCount() {
        viewModelScope.launch {
            try {
                val count = notificationRepository.getNewNotificationsCount()
                _notificationsCount.value = count
            } catch (e: Exception) {
                // Log error
            }
        }
    }
    
    private fun checkDueInstallments() {
        viewModelScope.launch {
            try {
                // Get current date
                val currentDate = Date()
                
                // Get date 3 days from now
                val calendar = Calendar.getInstance()
                calendar.time = currentDate
                calendar.add(Calendar.DAY_OF_MONTH, 3)
                val threeDaysFromNow = calendar.time
                
                // Get installments due in the next 3 days
                val dueInstallments = installmentRepository.getDueInstallmentsInPeriod(currentDate, threeDaysFromNow)
                
                // Create notifications for due installments
                for (installment in dueInstallments) {
                    notificationRepository.createNotification(
                        installmentId = installment.installmentId,
                        notificationDate = currentDate,
                        type = "due_installment"
                    )
                }
                
                // Get late installments
                val lateInstallments = installmentRepository.getLateInstallments()
                
                // Create notifications for late installments
                for (installment in lateInstallments) {
                    notificationRepository.createNotification(
                        installmentId = installment.installmentId,
                        notificationDate = currentDate,
                        type = "late_payment"
                    )
                }
                
                // Refresh notifications count
                loadNotificationsCount()
            } catch (e: Exception) {
                // Log error
            }
        }
    }
}

sealed class HomeState {
    object Loading : HomeState()
    object Success : HomeState()
    data class Error(val message: String) : HomeState()
}
