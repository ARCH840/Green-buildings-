package com.greenbuildings.app.repository

import com.greenbuildings.app.database.dao.*
import com.greenbuildings.app.database.entities.*
import java.util.*

class UserRepository(private val userDao: UserDao) {
    suspend fun getUserByUsername(username: String): User? {
        return userDao.getUserByUsername(username)
    }
    
    suspend fun insertUser(username: String, password: String): Long {
        val user = User(
            username = username,
            password = password,
            createdAt = Date(),
            lastLogin = null
        )
        return userDao.insertUser(user)
    }
    
    suspend fun updateLastLogin(userId: Long) {
        userDao.updateLastLogin(userId, Date())
    }
}

class BuildingRepository(private val buildingDao: BuildingDao) {
    suspend fun getAllBuildings(): List<Building> {
        return buildingDao.getAllBuildings()
    }
    
    suspend fun getBuildingById(buildingId: Long): Building? {
        return buildingDao.getBuildingById(buildingId)
    }
    
    suspend fun insertBuilding(name: String, address: String, totalApartments: Int, logoPath: String?): Long {
        val building = Building(
            name = name,
            address = address,
            totalApartments = totalApartments,
            availableApartments = totalApartments,
            logoPath = logoPath,
            createdAt = Date(),
            updatedAt = Date()
        )
        return buildingDao.insertBuilding(building)
    }
    
    suspend fun updateBuilding(building: Building) {
        building.updatedAt = Date()
        buildingDao.updateBuilding(building)
    }
    
    suspend fun deleteBuilding(building: Building) {
        buildingDao.deleteBuilding(building)
    }
    
    suspend fun decrementAvailableApartments(buildingId: Long) {
        buildingDao.decrementAvailableApartments(buildingId)
    }
}

class ApartmentRepository(private val apartmentDao: ApartmentDao) {
    suspend fun getApartmentsByBuilding(buildingId: Long): List<Apartment> {
        return apartmentDao.getApartmentsByBuilding(buildingId)
    }
    
    suspend fun getAvailableApartmentsByBuilding(buildingId: Long): List<Apartment> {
        return apartmentDao.getAvailableApartmentsByBuilding(buildingId)
    }
    
    suspend fun getApartmentById(apartmentId: Long): Apartment? {
        return apartmentDao.getApartmentById(apartmentId)
    }
    
    suspend fun insertApartment(
        buildingId: Long,
        name: String,
        floor: String,
        area: Double,
        pricePerMeter: Double,
        currency: String,
        imagePath: String?
    ): Long {
        val totalPrice = area * pricePerMeter
        val apartment = Apartment(
            buildingId = buildingId,
            name = name,
            floor = floor,
            area = area,
            pricePerMeter = pricePerMeter,
            totalPrice = totalPrice,
            currency = currency,
            status = "available",
            imagePath = imagePath,
            createdAt = Date(),
            updatedAt = Date()
        )
        return apartmentDao.insertApartment(apartment)
    }
    
    suspend fun updateApartment(apartment: Apartment) {
        apartment.updatedAt = Date()
        apartmentDao.updateApartment(apartment)
    }
    
    suspend fun deleteApartment(apartment: Apartment) {
        apartmentDao.deleteApartment(apartment)
    }
    
    suspend fun markApartmentAsSold(apartmentId: Long) {
        apartmentDao.markApartmentAsSold(apartmentId)
    }
}

class BuyerRepository(private val buyerDao: BuyerDao) {
    suspend fun getAllBuyers(): List<Buyer> {
        return buyerDao.getAllBuyers()
    }
    
    suspend fun getBuyerById(buyerId: Long): Buyer? {
        return buyerDao.getBuyerById(buyerId)
    }
    
    suspend fun insertBuyer(name: String, phone: String, idImagePath: String?): Long {
        val buyer = Buyer(
            name = name,
            phone = phone,
            idImagePath = idImagePath,
            createdAt = Date(),
            updatedAt = Date()
        )
        return buyerDao.insertBuyer(buyer)
    }
    
    suspend fun updateBuyer(buyer: Buyer) {
        buyer.updatedAt = Date()
        buyerDao.updateBuyer(buyer)
    }
}

class SaleRepository(
    private val saleDao: SaleDao,
    private val apartmentDao: ApartmentDao,
    private val buildingDao: BuildingDao,
    private val installmentDao: InstallmentDao
) {
    suspend fun getAllSales(): List<Sale> {
        return saleDao.getAllSales()
    }
    
    suspend fun getSaleById(saleId: Long): Sale? {
        return saleDao.getSaleById(saleId)
    }
    
    suspend fun getSaleByApartmentId(apartmentId: Long): Sale? {
        return saleDao.getSaleByApartmentId(apartmentId)
    }
    
    suspend fun getSalesByBuyerId(buyerId: Long): List<Sale> {
        return saleDao.getSalesByBuyerId(buyerId)
    }
    
    suspend fun createSale(
        apartmentId: Long,
        buyerId: Long,
        paymentType: String,
        downPaymentPercentage: Double?,
        downPaymentAmount: Double?,
        downPaymentDate: Date?,
        downPaymentStatus: String?,
        downPaymentReceiptPath: String?,
        installmentType: String?,
        installmentPeriod: Int?,
        installmentFrequency: String?
    ): Long {
        val apartment = apartmentDao.getApartmentById(apartmentId)
            ?: throw IllegalArgumentException("Apartment not found")
        
        val totalAmount = apartment.totalPrice
        val remainingAmount = if (paymentType == "cash") 0.0 else (totalAmount - (downPaymentAmount ?: 0.0))
        
        val sale = Sale(
            apartmentId = apartmentId,
            buyerId = buyerId,
            saleDate = Date(),
            totalAmount = totalAmount,
            paymentType = paymentType,
            downPaymentPercentage = downPaymentPercentage,
            downPaymentAmount = downPaymentAmount,
            downPaymentDate = downPaymentDate,
            downPaymentStatus = downPaymentStatus,
            downPaymentReceiptPath = downPaymentReceiptPath,
            remainingAmount = remainingAmount,
            installmentType = installmentType,
            installmentPeriod = installmentPeriod,
            installmentFrequency = installmentFrequency,
            createdAt = Date(),
            updatedAt = Date()
        )
        
        val saleId = saleDao.insertSale(sale)
        
        // Mark apartment as sold
        apartmentDao.markApartmentAsSold(apartmentId)
        
        // Decrement available apartments count in building
        buildingDao.decrementAvailableApartments(apartment.buildingId)
        
        // Create installments if payment type is installments
        if (paymentType == "installments" && installmentType == "scheduled" && installmentPeriod != null && installmentFrequency != null) {
            createScheduledInstallments(
                saleId,
                remainingAmount,
                installmentPeriod,
                installmentFrequency,
                downPaymentDate ?: Date()
            )
        }
        
        return saleId
    }
    
    private suspend fun createScheduledInstallments(
        saleId: Long,
        totalAmount: Double,
        periodInMonths: Int,
        frequency: String,
        startDate: Date
    ) {
        val frequencyInMonths = when (frequency) {
            "monthly" -> 1
            "bimonthly" -> 2
            "quarterly" -> 3
            "biannually" -> 6
            else -> 1
        }
        
        val numberOfInstallments = periodInMonths / frequencyInMonths
        val installmentAmount = totalAmount / numberOfInstallments
        
        val calendar = Calendar.getInstance()
        calendar.time = startDate
        
        val installments = mutableListOf<Installment>()
        
        for (i in 1..numberOfInstallments) {
            calendar.add(Calendar.MONTH, frequencyInMonths)
            
            val installment = Installment(
                saleId = saleId,
                amount = installmentAmount,
                dueDate = calendar.time,
                status = "due",
                paidAmount = null,
                remainingAmount = null,
                paymentDate = null,
                receiptPath = null,
                nextPaymentDate = null,
                notes = null,
                createdAt = Date(),
                updatedAt = Date()
            )
            
            installments.add(installment)
        }
        
        installmentDao.insertInstallments(installments)
    }
    
    suspend fun updateSale(sale: Sale) {
        sale.updatedAt = Date()
        saleDao.updateSale(sale)
    }
}

class InstallmentRepository(
    private val installmentDao: InstallmentDao,
    private val notificationDao: NotificationDao,
    private val receiptDao: ReceiptDao
) {
    suspend fun getInstallmentsBySaleId(saleId: Long): List<Installment> {
        return installmentDao.getInstallmentsBySaleId(saleId)
    }
    
    suspend fun getInstallmentById(installmentId: Long): Installment? {
        return installmentDao.getInstallmentById(installmentId)
    }
    
    suspend fun getDueInstallmentsInPeriod(startDate: Date, endDate: Date): List<Installment> {
        return installmentDao.getDueInstallmentsInPeriod(startDate, endDate)
    }
    
    suspend fun getLateInstallments(): List<Installment> {
        return installmentDao.getLateInstallments()
    }
    
    suspend fun insertInstallment(
        saleId: Long,
        amount: Double,
        dueDate: Date
    ): Long {
        val installment = Installment(
            saleId = saleId,
            amount = amount,
            dueDate = dueDate,
            status = "due",
            paidAmount = null,
            remainingAmount = null,
            paymentDate = null,
            receiptPath = null,
            nextPaymentDate = null,
            notes = null,
            createdAt = Date(),
            updatedAt = Date()
        )
        return installmentDao.insertInstallment(installment)
    }
    
    suspend fun markInstallmentAsPaid(
        installmentId: Long,
        paymentDate: Date,
        receiptPath: String?
    ) {
        installmentDao.markInstallmentAsPaid(
            installmentId = installmentId,
            paymentDate = paymentDate,
            receiptPath = receiptPath,
            updatedAt = Date()
        )
        
        // Mark any notifications for this installment as read
        notificationDao.markNotificationsAsReadByInstallmentId(installmentId)
    }
    
    suspend fun updatePartialPayment(
        installmentId: Long,
        paidAmount: Double,
        paymentDate: Date,
        nextPaymentDate: Date
    ) {
        installmentDao.updatePartialPayment(
            installmentId = installmentId,
            paidAmount = paidAmount,
            paymentDate = paymentDate,
            nextPaymentDate = nextPaymentDate,
            updatedAt = Date()
        )
    }
    
    suspend fun createReceipt(
        saleId: Long,
        installmentId: Long?,
        amount: Double,
        paymentDate: Date,
        receiptNumber: String,
        receiptPath: String?
    ): Long {
        val receipt = Receipt(
            saleId = saleId,
            installmentId = installmentId,
            amount = amount,
            paymentDate = paymentDate,
            receiptNumber = receiptNumber,
            receiptPath = receiptPath,
            createdAt = Date()
        )
        return receiptDao.insertReceipt(receipt)
    }
}

class ReceiptRepository(private val receiptDao: ReceiptDao) {
    suspend fun getReceiptsBySaleId(saleId: Long): List<Receipt> {
        return receiptDao.getReceiptsBySaleId(saleId)
    }
    
    suspend fun getReceiptsByInstallmentId(installmentId: Long): List<Receipt> {
        return receiptDao.getReceiptsByInstallmentId(installmentId)
    }
    
    suspend fun getReceiptById(receiptId: Long): Receipt? {
        return receiptDao.getReceiptById(receiptId)
    }
}

class NotificationRepository(private val notificationDao: NotificationDao) {
    suspend fun getNewNotifications(): List<Notification> {
        return notificationDao.getNewNotifications()
    }
    
    suspend fun getAllNotifications(): List<Notification> {
        return notificationDao.getAllNotifications()
    }
    
    suspend fun getNewNotificationsCount(): Int {
        return notificationDao.getNewNotificationsCount()
    }
    
    suspend fun createNotification(
        installmentId: Long,
        notificationDate: Date,
        type: String
    ): Long {
        val notification = Notification(
            installmentId = installmentId,
            notificationDate = notificationDate,
            status = "new",
            type = type,
            createdAt = Date()
        )
        return notificationDao.insertNotification(notification)
    }
    
    suspend fun markNotificationAsRead(notificationId: Long) {
        notificationDao.markNotificationAsRead(notificationId)
    }
}
