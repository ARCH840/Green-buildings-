package com.greenbuildings.app.database.dao

import androidx.room.*
import com.greenbuildings.app.database.entities.*
import java.util.Date

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): User?
    
    @Insert
    suspend fun insertUser(user: User): Long
    
    @Update
    suspend fun updateUser(user: User)
    
    @Query("UPDATE users SET lastLogin = :lastLogin WHERE userId = :userId")
    suspend fun updateLastLogin(userId: Long, lastLogin: Date)
}

@Dao
interface BuildingDao {
    @Query("SELECT * FROM buildings ORDER BY name ASC")
    suspend fun getAllBuildings(): List<Building>
    
    @Query("SELECT * FROM buildings WHERE buildingId = :buildingId")
    suspend fun getBuildingById(buildingId: Long): Building?
    
    @Insert
    suspend fun insertBuilding(building: Building): Long
    
    @Update
    suspend fun updateBuilding(building: Building)
    
    @Delete
    suspend fun deleteBuilding(building: Building)
    
    @Query("UPDATE buildings SET availableApartments = availableApartments - 1 WHERE buildingId = :buildingId")
    suspend fun decrementAvailableApartments(buildingId: Long)
}

@Dao
interface ApartmentDao {
    @Query("SELECT * FROM apartments WHERE buildingId = :buildingId ORDER BY name ASC")
    suspend fun getApartmentsByBuilding(buildingId: Long): List<Apartment>
    
    @Query("SELECT * FROM apartments WHERE status = 'available' AND buildingId = :buildingId ORDER BY name ASC")
    suspend fun getAvailableApartmentsByBuilding(buildingId: Long): List<Apartment>
    
    @Query("SELECT * FROM apartments WHERE apartmentId = :apartmentId")
    suspend fun getApartmentById(apartmentId: Long): Apartment?
    
    @Insert
    suspend fun insertApartment(apartment: Apartment): Long
    
    @Update
    suspend fun updateApartment(apartment: Apartment)
    
    @Delete
    suspend fun deleteApartment(apartment: Apartment)
    
    @Query("UPDATE apartments SET status = 'sold' WHERE apartmentId = :apartmentId")
    suspend fun markApartmentAsSold(apartmentId: Long)
}

@Dao
interface BuyerDao {
    @Query("SELECT * FROM buyers ORDER BY name ASC")
    suspend fun getAllBuyers(): List<Buyer>
    
    @Query("SELECT * FROM buyers WHERE buyerId = :buyerId")
    suspend fun getBuyerById(buyerId: Long): Buyer?
    
    @Insert
    suspend fun insertBuyer(buyer: Buyer): Long
    
    @Update
    suspend fun updateBuyer(buyer: Buyer)
}

@Dao
interface SaleDao {
    @Query("SELECT * FROM sales ORDER BY saleDate DESC")
    suspend fun getAllSales(): List<Sale>
    
    @Query("SELECT * FROM sales WHERE saleId = :saleId")
    suspend fun getSaleById(saleId: Long): Sale?
    
    @Query("SELECT * FROM sales WHERE apartmentId = :apartmentId")
    suspend fun getSaleByApartmentId(apartmentId: Long): Sale?
    
    @Query("SELECT * FROM sales WHERE buyerId = :buyerId")
    suspend fun getSalesByBuyerId(buyerId: Long): List<Sale>
    
    @Insert
    suspend fun insertSale(sale: Sale): Long
    
    @Update
    suspend fun updateSale(sale: Sale)
}

@Dao
interface InstallmentDao {
    @Query("SELECT * FROM installments WHERE saleId = :saleId ORDER BY dueDate ASC")
    suspend fun getInstallmentsBySaleId(saleId: Long): List<Installment>
    
    @Query("SELECT * FROM installments WHERE installmentId = :installmentId")
    suspend fun getInstallmentById(installmentId: Long): Installment?
    
    @Query("SELECT * FROM installments WHERE status = 'due' AND dueDate BETWEEN :startDate AND :endDate ORDER BY dueDate ASC")
    suspend fun getDueInstallmentsInPeriod(startDate: Date, endDate: Date): List<Installment>
    
    @Query("SELECT * FROM installments WHERE status = 'late' ORDER BY dueDate ASC")
    suspend fun getLateInstallments(): List<Installment>
    
    @Insert
    suspend fun insertInstallment(installment: Installment): Long
    
    @Insert
    suspend fun insertInstallments(installments: List<Installment>)
    
    @Update
    suspend fun updateInstallment(installment: Installment)
    
    @Query("UPDATE installments SET status = 'paid', paidAmount = amount, remainingAmount = 0, paymentDate = :paymentDate, receiptPath = :receiptPath, updatedAt = :updatedAt WHERE installmentId = :installmentId")
    suspend fun markInstallmentAsPaid(installmentId: Long, paymentDate: Date, receiptPath: String?, updatedAt: Date)
    
    @Query("UPDATE installments SET paidAmount = :paidAmount, remainingAmount = amount - :paidAmount, paymentDate = :paymentDate, nextPaymentDate = :nextPaymentDate, updatedAt = :updatedAt WHERE installmentId = :installmentId")
    suspend fun updatePartialPayment(installmentId: Long, paidAmount: Double, paymentDate: Date, nextPaymentDate: Date, updatedAt: Date)
}

@Dao
interface ReceiptDao {
    @Query("SELECT * FROM receipts WHERE saleId = :saleId ORDER BY paymentDate DESC")
    suspend fun getReceiptsBySaleId(saleId: Long): List<Receipt>
    
    @Query("SELECT * FROM receipts WHERE installmentId = :installmentId")
    suspend fun getReceiptsByInstallmentId(installmentId: Long): List<Receipt>
    
    @Query("SELECT * FROM receipts WHERE receiptId = :receiptId")
    suspend fun getReceiptById(receiptId: Long): Receipt?
    
    @Insert
    suspend fun insertReceipt(receipt: Receipt): Long
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE status = 'new' ORDER BY notificationDate DESC")
    suspend fun getNewNotifications(): List<Notification>
    
    @Query("SELECT * FROM notifications ORDER BY notificationDate DESC")
    suspend fun getAllNotifications(): List<Notification>
    
    @Query("SELECT COUNT(*) FROM notifications WHERE status = 'new'")
    suspend fun getNewNotificationsCount(): Int
    
    @Insert
    suspend fun insertNotification(notification: Notification): Long
    
    @Query("UPDATE notifications SET status = 'read' WHERE notificationId = :notificationId")
    suspend fun markNotificationAsRead(notificationId: Long)
    
    @Query("UPDATE notifications SET status = 'read' WHERE installmentId = :installmentId")
    suspend fun markNotificationsAsReadByInstallmentId(installmentId: Long)
}
