package com.greenbuildings.app.ui.backup

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class BackupViewModel : ViewModel() {
    
    private val _backups = MutableLiveData<List<BackupInfo>>()
    val backups: LiveData<List<BackupInfo>> = _backups
    
    private val _state = MutableLiveData<BackupState>()
    val state: LiveData<BackupState> = _state
    
    private val backupDirectory = File("/data/data/com.greenbuildings.app/backup")
    
    init {
        loadBackups()
    }
    
    private fun loadBackups() {
        viewModelScope.launch {
            try {
                _state.value = BackupState.Loading
                
                if (!backupDirectory.exists()) {
                    backupDirectory.mkdirs()
                }
                
                val backupFiles = backupDirectory.listFiles()?.filter { it.isFile && it.name.endsWith(".db") } ?: emptyList()
                
                val backupInfoList = backupFiles.map { file ->
                    BackupInfo(
                        fileName = file.name,
                        date = parseBackupDate(file.name),
                        size = formatFileSize(file.length())
                    )
                }.sortedByDescending { it.date }
                
                _backups.value = backupInfoList
                _state.value = BackupState.Success
            } catch (e: Exception) {
                _state.value = BackupState.Error("حدث خطأ أثناء تحميل النسخ الاحتياطية: ${e.message}")
            }
        }
    }
    
    fun createBackup() {
        viewModelScope.launch {
            try {
                _state.value = BackupState.Loading
                
                if (!backupDirectory.exists()) {
                    backupDirectory.mkdirs()
                }
                
                val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                val backupFileName = "backup_${dateFormat.format(Date())}.db"
                val backupFile = File(backupDirectory, backupFileName)
                
                // In a real implementation, we would copy the database file to the backup location
                // For this example, we'll just create an empty file
                backupFile.createNewFile()
                
                loadBackups()
                _state.value = BackupState.Success
            } catch (e: Exception) {
                _state.value = BackupState.Error("حدث خطأ أثناء إنشاء النسخة الاحتياطية: ${e.message}")
            }
        }
    }
    
    fun restoreBackup(fileName: String) {
        viewModelScope.launch {
            try {
                _state.value = BackupState.Loading
                
                val backupFile = File(backupDirectory, fileName)
                if (!backupFile.exists()) {
                    throw IllegalArgumentException("ملف النسخة الاحتياطية غير موجود")
                }
                
                // In a real implementation, we would restore the database from the backup file
                // For this example, we'll just simulate a delay
                kotlinx.coroutines.delay(1000)
                
                _state.value = BackupState.Success
            } catch (e: Exception) {
                _state.value = BackupState.Error("حدث خطأ أثناء استعادة النسخة الاحتياطية: ${e.message}")
            }
        }
    }
    
    fun deleteBackup(fileName: String) {
        viewModelScope.launch {
            try {
                _state.value = BackupState.Loading
                
                val backupFile = File(backupDirectory, fileName)
                if (backupFile.exists()) {
                    backupFile.delete()
                }
                
                loadBackups()
                _state.value = BackupState.Success
            } catch (e: Exception) {
                _state.value = BackupState.Error("حدث خطأ أثناء حذف النسخة الاحتياطية: ${e.message}")
            }
        }
    }
    
    fun exportBackup(fileName: String, exportPath: String) {
        viewModelScope.launch {
            try {
                _state.value = BackupState.Loading
                
                val backupFile = File(backupDirectory, fileName)
                if (!backupFile.exists()) {
                    throw IllegalArgumentException("ملف النسخة الاحتياطية غير موجود")
                }
                
                val exportFile = File(exportPath)
                
                // In a real implementation, we would copy the backup file to the export location
                // For this example, we'll just simulate a delay
                kotlinx.coroutines.delay(1000)
                
                _state.value = BackupState.Success
            } catch (e: Exception) {
                _state.value = BackupState.Error("حدث خطأ أثناء تصدير النسخة الاحتياطية: ${e.message}")
            }
        }
    }
    
    fun importBackup(importPath: String) {
        viewModelScope.launch {
            try {
                _state.value = BackupState.Loading
                
                val importFile = File(importPath)
                if (!importFile.exists()) {
                    throw IllegalArgumentException("ملف النسخة الاحتياطية غير موجود")
                }
                
                if (!backupDirectory.exists()) {
                    backupDirectory.mkdirs()
                }
                
                val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                val backupFileName = "backup_${dateFormat.format(Date())}_imported.db"
                val backupFile = File(backupDirectory, backupFileName)
                
                // In a real implementation, we would copy the import file to the backup location
                // For this example, we'll just create an empty file
                backupFile.createNewFile()
                
                loadBackups()
                _state.value = BackupState.Success
            } catch (e: Exception) {
                _state.value = BackupState.Error("حدث خطأ أثناء استيراد النسخة الاحتياطية: ${e.message}")
            }
        }
    }
    
    private fun parseBackupDate(fileName: String): Date {
        try {
            val datePattern = "backup_(\\d{8}_\\d{6})"
            val regex = Regex(datePattern)
            val matchResult = regex.find(fileName)
            
            if (matchResult != null) {
                val dateStr = matchResult.groupValues[1]
                val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US)
                return dateFormat.parse(dateStr) ?: Date()
            }
        } catch (e: Exception) {
            // If parsing fails, return current date
        }
        
        return Date()
    }
    
    private fun formatFileSize(size: Long): String {
        val kb = size / 1024.0
        val mb = kb / 1024.0
        
        return when {
            mb >= 1.0 -> String.format("%.1f MB", mb)
            kb >= 1.0 -> String.format("%.1f KB", kb)
            else -> "$size bytes"
        }
    }
}

data class BackupInfo(
    val fileName: String,
    val date: Date,
    val size: String
)

sealed class BackupState {
    object Loading : BackupState()
    object Success : BackupState()
    data class Error(val message: String) : BackupState()
}
