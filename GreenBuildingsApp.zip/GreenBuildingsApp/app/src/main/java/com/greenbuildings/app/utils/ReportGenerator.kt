package com.greenbuildings.app.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.pdf.PdfDocument
import android.os.Environment
import android.view.View
import com.greenbuildings.app.database.entities.Installment
import com.greenbuildings.app.database.entities.Receipt
import com.greenbuildings.app.database.entities.Sale
import com.itextpdf.text.Document
import com.itextpdf.text.Font
import com.itextpdf.text.Paragraph
import com.itextpdf.text.pdf.BaseFont
import com.itextpdf.text.pdf.PdfWriter
import org.apache.poi.hssf.usermodel.HSSFWorkbook
import org.apache.poi.ss.usermodel.Row
import org.apache.poi.ss.usermodel.Sheet
import org.apache.poi.ss.usermodel.Workbook
import java.io.File
import java.io.FileOutputStream
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ReportGenerator(private val context: Context) {
    
    private val arabicDateFormat = SimpleDateFormat("yyyy/MM/dd", Locale("ar"))
    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale("ar", "SA"))
    
    fun generateTotalSalesReportPdf(
        sales: List<Sale>,
        totalSalesAmount: Double,
        totalCollections: Double,
        totalDues: Double,
        startDate: Date,
        endDate: Date
    ): File {
        val pdfFile = File(
            context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
            "تقرير_المبيعات_الإجمالي_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.pdf"
        )
        
        try {
            val document = Document()
            PdfWriter.getInstance(document, FileOutputStream(pdfFile))
            document.open()
            
            // Set up Arabic font
            val baseFont = BaseFont.createFont(
                "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
                BaseFont.IDENTITY_H,
                BaseFont.EMBEDDED
            )
            val arabicFont = Font(baseFont, 12f)
            val titleFont = Font(baseFont, 18f, Font.BOLD)
            val subtitleFont = Font(baseFont, 14f, Font.BOLD)
            
            // Add title
            document.add(Paragraph("تقرير المبيعات الإجمالي", titleFont))
            document.add(Paragraph("Green Buildings للتطوير العقاري والمقاولات", subtitleFont))
            document.add(Paragraph("\n"))
            
            // Add report period
            document.add(Paragraph("الفترة: من ${arabicDateFormat.format(startDate)} إلى ${arabicDateFormat.format(endDate)}", arabicFont))
            document.add(Paragraph("\n"))
            
            // Add summary
            document.add(Paragraph("ملخص التقرير:", subtitleFont))
            document.add(Paragraph("إجمالي المبيعات: ${currencyFormat.format(totalSalesAmount)}", arabicFont))
            document.add(Paragraph("إجمالي التحصيلات: ${currencyFormat.format(totalCollections)}", arabicFont))
            document.add(Paragraph("إجمالي المستحقات: ${currencyFormat.format(totalDues)}", arabicFont))
            document.add(Paragraph("\n"))
            
            // Add sales details
            document.add(Paragraph("تفاصيل المبيعات:", subtitleFont))
            
            for (sale in sales) {
                document.add(Paragraph("رقم البيع: ${sale.saleId}", arabicFont))
                document.add(Paragraph("تاريخ البيع: ${arabicDateFormat.format(sale.saleDate)}", arabicFont))
                document.add(Paragraph("المبلغ الإجمالي: ${currencyFormat.format(sale.totalAmount)}", arabicFont))
                document.add(Paragraph("طريقة الدفع: ${if (sale.paymentType == "cash") "كاش" else "أقساط"}", arabicFont))
                
                if (sale.paymentType == "installments") {
                    document.add(Paragraph("الدفعة المقدمة: ${currencyFormat.format(sale.downPaymentAmount ?: 0.0)}", arabicFont))
                    document.add(Paragraph("المبلغ المتبقي: ${currencyFormat.format(sale.remainingAmount ?: 0.0)}", arabicFont))
                }
                
                document.add(Paragraph("-------------------------------------------", arabicFont))
            }
            
            document.close()
            return pdfFile
        } catch (e: Exception) {
            throw e
        }
    }
    
    fun generateTotalSalesReportExcel(
        sales: List<Sale>,
        totalSalesAmount: Double,
        totalCollections: Double,
        totalDues: Double,
        startDate: Date,
        endDate: Date
    ): File {
        val excelFile = File(
            context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
            "تقرير_المبيعات_الإجمالي_${SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())}.xls"
        )
        
        try {
            val workbook: Workbook = HSSFWorkbook()
            val sheet: Sheet = workbook.createSheet("تقرير المبيعات الإجمالي")
            
            // Create header row
            var rowIndex = 0
            var row: Row = sheet.createRow(rowIndex++)
            row.createCell(0).setCellValue("تقرير المبيعات الإجمالي")
            
            row = sheet.createRow(rowIndex++)
            row.createCell(0).setCellValue("الفترة: من ${arabicDateFormat.format(startDate)} إلى ${arabicDateFormat.format(endDate)}")
            
            // Add summary
            rowIndex++
            row = sheet.createRow(rowIndex++)
            row.createCell(0).setCellValue("ملخص التقرير:")
            
            row = sheet.createRow(rowIndex++)
            row.createCell(0).setCellValue("إجمالي المبيعات:")
            row.createCell(1).setCellValue(totalSalesAmount)
            
            row = sheet.createRow(rowIndex++)
            row.createCell(0).setCellValue("إجمالي التحصيلات:")
            row.createCell(1).setCellValue(totalCollections)
            
            row = sheet.createRow(rowIndex++)
            row.createCell(0).setCellValue("إجمالي المستحقات:")
            row.createCell(1).setCellValue(totalDues)
            
            // Add sales details
            rowIndex++
            row = sheet.createRow(rowIndex++)
            row.createCell(0).setCellValue("تفاصيل المبيعات:")
            
            row = sheet.createRow(rowIndex++)
            row.createCell(0).setCellValue("رقم البيع")
            row.createCell(1).setCellValue("تاريخ البيع")
            row.createCell(2).setCellValue("المبلغ الإجمالي")
            row.createCell(3).setCellValue("طريقة الدفع")
            row.createCell(4).setCellValue("الدفعة المقدمة")
            row.createCell(5).setCellValue("المبلغ المتبقي")
            
            for (sale in sales) {
                row = sheet.createRow(rowIndex++)
                row.createCell(0).setCellValue(sale.saleId.toString())
                row.createCell(1).setCellValue(arabicDateFormat.format(sale.saleDate))
                row.createCell(2).setCellValue(sale.totalAmount)
                row.createCell(3).setCellValue(if (sale.paymentType == "cash") "كاش" else "أقساط")
                row.createCell(4).setCellValue(sale.downPaymentAmount ?: 0.0)
                row.createCell(5).setCellValue(sale.remainingAmount ?: 0.0)
            }
            
            // Auto size columns
            for (i in 0..5) {
                sheet.autoSizeColumn(i)
            }
            
            val fileOutputStream = FileOutputStream(excelFile)
            workbook.write(fileOutputStream)
            fileOutputStream.close()
            workbook.close()
            
            return excelFile
        } catch (e: Exception) {
            throw e
        }
    }
    
    fun generateReceiptPdf(
        receipt: Receipt,
        sale: Sale,
        buyerName: String,
        apartmentName: String,
        buildingName: String,
        installment: Installment?,
        totalInstallments: Int
    ): File {
        val pdfFile = File(
            context.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
            "سند_قبض_${receipt.receiptNumber}.pdf"
        )
        
        try {
            val document = Document()
            PdfWriter.getInstance(document, FileOutputStream(pdfFile))
            document.open()
            
            // Set up Arabic font
            val baseFont = BaseFont.createFont(
                "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
                BaseFont.IDENTITY_H,
                BaseFont.EMBEDDED
            )
            val arabicFont = Font(baseFont, 12f)
            val titleFont = Font(baseFont, 18f, Font.BOLD)
            val subtitleFont = Font(baseFont, 14f, Font.BOLD)
            
            // Add title
            document.add(Paragraph("سند قبض", titleFont))
            document.add(Paragraph("Green Buildings للتطوير العقاري والمقاولات", subtitleFont))
            document.add(Paragraph("\n"))
            
            // Add receipt details
            document.add(Paragraph("رقم السند: ${receipt.receiptNumber}", arabicFont))
            document.add(Paragraph("التاريخ: ${arabicDateFormat.format(receipt.paymentDate)}", arabicFont))
            document.add(Paragraph("\n"))
            
            document.add(Paragraph("استلمنا من السيد/ة: ${buyerName}", arabicFont))
            
            // Convert amount to words (simplified for example)
            val amountInWords = "مبلغ وقدره: ${currencyFormat.format(receipt.amount)}"
            document.add(Paragraph(amountInWords, arabicFont))
            document.add(Paragraph("\n"))
            
            if (installment != null) {
                document.add(Paragraph("وذلك عن: سداد القسط رقم ${getInstallmentNumber(installment, sale)} من أصل $totalInstallments قسط", arabicFont))
            } else {
                document.add(Paragraph("وذلك عن: سداد الدفعة المقدمة", arabicFont))
            }
            
            document.add(Paragraph("للشقة: $apartmentName - $buildingName", arabicFont))
            document.add(Paragraph("\n"))
            
            document.add(Paragraph("المبلغ الإجمالي للشقة: ${currencyFormat.format(sale.totalAmount)}", arabicFont))
            
            // Calculate previously paid amount
            val previouslyPaid = calculatePreviouslyPaid(sale, receipt)
            document.add(Paragraph("المبلغ المدفوع سابقاً: ${currencyFormat.format(previouslyPaid)}", arabicFont))
            document.add(Paragraph("المبلغ المدفوع حالياً: ${currencyFormat.format(receipt.amount)}", arabicFont))
            
            // Calculate remaining amount
            val remainingAmount = sale.totalAmount - (previouslyPaid + receipt.amount)
            document.add(Paragraph("المبلغ المتبقي: ${currencyFormat.format(remainingAmount)}", arabicFont))
            document.add(Paragraph("\n\n"))
            
            document.add(Paragraph("توقيع المستلم: ____________", arabicFont))
            document.add(Paragraph("\n"))
            document.add(Paragraph("ختم الشركة:", arabicFont))
            
            document.close()
            return pdfFile
        } catch (e: Exception) {
            throw e
        }
    }
    
    private fun getInstallmentNumber(installment: Installment, sale: Sale): Int {
        // In a real implementation, we would query the database to get the installment number
        // For this example, we'll return a placeholder
        return 1
    }
    
    private fun calculatePreviouslyPaid(sale: Sale, currentReceipt: Receipt): Double {
        // In a real implementation, we would query the database to calculate the previously paid amount
        // For this example, we'll return a placeholder
        return if (sale.downPaymentAmount != null) sale.downPaymentAmount else 0.0
    }
    
    fun captureView(view: View): Bitmap {
        val bitmap = Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        view.draw(canvas)
        return bitmap
    }
}
