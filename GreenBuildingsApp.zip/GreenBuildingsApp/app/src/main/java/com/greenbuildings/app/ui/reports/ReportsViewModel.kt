package com.greenbuildings.app.ui.reports

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.greenbuildings.app.database.entities.Building
import com.greenbuildings.app.database.entities.Installment
import com.greenbuildings.app.database.entities.Sale
import com.greenbuildings.app.repository.BuildingRepository
import com.greenbuildings.app.repository.InstallmentRepository
import com.greenbuildings.app.repository.SaleRepository
import kotlinx.coroutines.launch
import java.util.Calendar
import java.util.Date

class ReportsViewModel(
    private val saleRepository: SaleRepository,
    private val installmentRepository: InstallmentRepository,
    private val buildingRepository: BuildingRepository
) : ViewModel() {
    
    private val _state = MutableLiveData<ReportsState>()
    val state: LiveData<ReportsState> = _state
    
    private val _totalSalesReport = MutableLiveData<TotalSalesReport>()
    val totalSalesReport: LiveData<TotalSalesReport> = _totalSalesReport
    
    private val _dueInstallments = MutableLiveData<List<Installment>>()
    val dueInstallments: LiveData<List<Installment>> = _dueInstallments
    
    private val _lateInstallments = MutableLiveData<List<Installment>>()
    val lateInstallments: LiveData<List<Installment>> = _lateInstallments
    
    private val _buildingSalesReport = MutableLiveData<BuildingSalesReport>()
    val buildingSalesReport: LiveData<BuildingSalesReport> = _buildingSalesReport
    
    private val _periodSalesReport = MutableLiveData<PeriodSalesReport>()
    val periodSalesReport: LiveData<PeriodSalesReport> = _periodSalesReport
    
    private val _buildings = MutableLiveData<List<Building>>()
    val buildings: LiveData<List<Building>> = _buildings
    
    init {
        loadBuildings()
    }
    
    private fun loadBuildings() {
        viewModelScope.launch {
            try {
                val buildingsList = buildingRepository.getAllBuildings()
                _buildings.value = buildingsList
            } catch (e: Exception) {
                // Log error
            }
        }
    }
    
    fun generateTotalSalesReport(startDate: Date, endDate: Date) {
        viewModelScope.launch {
            try {
                _state.value = ReportsState.Loading
                
                // Get all sales
                val allSales = saleRepository.getAllSales()
                
                // Filter sales by date range
                val salesInPeriod = allSales.filter { sale ->
                    sale.saleDate in startDate..endDate
                }
                
                // Calculate total sales amount
                val totalSalesAmount = salesInPeriod.sumOf { it.totalAmount }
                
                // Calculate total collections (down payments + installments paid)
                var totalCollections = 0.0
                
                // Add down payments
                totalCollections += salesInPeriod
                    .filter { it.downPaymentStatus == "paid" }
                    .sumOf { it.downPaymentAmount ?: 0.0 }
                
                // Add paid installments
                for (sale in salesInPeriod) {
                    val installments = installmentRepository.getInstallmentsBySaleId(sale.saleId)
                    totalCollections += installments
                        .filter { it.status == "paid" }
                        .sumOf { it.amount }
                    
                    // Add partial payments
                    totalCollections += installments
                        .filter { it.status == "due" && it.paidAmount != null }
                        .sumOf { it.paidAmount ?: 0.0 }
                }
                
                // Calculate total dues
                val totalDues = totalSalesAmount - totalCollections
                
                // Create report
                val report = TotalSalesReport(
                    startDate = startDate,
                    endDate = endDate,
                    totalSalesAmount = totalSalesAmount,
                    totalCollections = totalCollections,
                    totalDues = totalDues,
                    sales = salesInPeriod
                )
                
                _totalSalesReport.value = report
                _state.value = ReportsState.Success
            } catch (e: Exception) {
                _state.value = ReportsState.Error("حدث خطأ أثناء إنشاء التقرير: ${e.message}")
            }
        }
    }
    
    fun generateDueInstallmentsReport() {
        viewModelScope.launch {
            try {
                _state.value = ReportsState.Loading
                
                // Get current date
                val currentDate = Date()
                
                // Get date 30 days from now
                val calendar = Calendar.getInstance()
                calendar.time = currentDate
                calendar.add(Calendar.DAY_OF_MONTH, 30)
                val thirtyDaysFromNow = calendar.time
                
                // Get installments due in the next 30 days
                val dueInstallmentsList = installmentRepository.getDueInstallmentsInPeriod(currentDate, thirtyDaysFromNow)
                
                _dueInstallments.value = dueInstallmentsList
                _state.value = ReportsState.Success
            } catch (e: Exception) {
                _state.value = ReportsState.Error("حدث خطأ أثناء إنشاء تقرير الأقساط المستحقة: ${e.message}")
            }
        }
    }
    
    fun generateLateInstallmentsReport() {
        viewModelScope.launch {
            try {
                _state.value = ReportsState.Loading
                
                // Get late installments
                val lateInstallmentsList = installmentRepository.getLateInstallments()
                
                _lateInstallments.value = lateInstallmentsList
                _state.value = ReportsState.Success
            } catch (e: Exception) {
                _state.value = ReportsState.Error("حدث خطأ أثناء إنشاء تقرير الأقساط المتأخرة: ${e.message}")
            }
        }
    }
    
    fun generateBuildingSalesReport(buildingId: Long) {
        viewModelScope.launch {
            try {
                _state.value = ReportsState.Loading
                
                // Get building details
                val building = buildingRepository.getBuildingById(buildingId)
                    ?: throw IllegalArgumentException("البرج غير موجود")
                
                // Get all sales
                val allSales = saleRepository.getAllSales()
                
                // Get all apartments for this building
                val apartments = mutableListOf<Long>()
                // Note: In a real implementation, we would get all apartments for this building
                // and then filter sales by apartment IDs
                
                // Filter sales for this building
                val buildingSales = allSales.filter { sale ->
                    // In a real implementation, we would check if sale.apartmentId is in the apartments list
                    // For now, we'll assume we can filter directly
                    apartments.contains(sale.apartmentId)
                }
                
                // Calculate total sales amount
                val totalSalesAmount = buildingSales.sumOf { it.totalAmount }
                
                // Calculate total collections
                var totalCollections = 0.0
                
                // Add down payments
                totalCollections += buildingSales
                    .filter { it.downPaymentStatus == "paid" }
                    .sumOf { it.downPaymentAmount ?: 0.0 }
                
                // Add paid installments
                for (sale in buildingSales) {
                    val installments = installmentRepository.getInstallmentsBySaleId(sale.saleId)
                    totalCollections += installments
                        .filter { it.status == "paid" }
                        .sumOf { it.amount }
                    
                    // Add partial payments
                    totalCollections += installments
                        .filter { it.status == "due" && it.paidAmount != null }
                        .sumOf { it.paidAmount ?: 0.0 }
                }
                
                // Calculate total dues
                val totalDues = totalSalesAmount - totalCollections
                
                // Create report
                val report = BuildingSalesReport(
                    building = building,
                    totalSalesAmount = totalSalesAmount,
                    totalCollections = totalCollections,
                    totalDues = totalDues,
                    sales = buildingSales
                )
                
                _buildingSalesReport.value = report
                _state.value = ReportsState.Success
            } catch (e: Exception) {
                _state.value = ReportsState.Error("حدث خطأ أثناء إنشاء تقرير مبيعات البرج: ${e.message}")
            }
        }
    }
    
    fun generatePeriodSalesReport(startDate: Date, endDate: Date) {
        viewModelScope.launch {
            try {
                _state.value = ReportsState.Loading
                
                // Get all sales
                val allSales = saleRepository.getAllSales()
                
                // Filter sales by date range
                val salesInPeriod = allSales.filter { sale ->
                    sale.saleDate in startDate..endDate
                }
                
                // Group sales by month
                val salesByMonth = salesInPeriod.groupBy { sale ->
                    val calendar = Calendar.getInstance()
                    calendar.time = sale.saleDate
                    "${calendar.get(Calendar.YEAR)}-${calendar.get(Calendar.MONTH) + 1}"
                }
                
                // Calculate monthly totals
                val monthlyTotals = salesByMonth.mapValues { (_, sales) ->
                    sales.sumOf { it.totalAmount }
                }
                
                // Create report
                val report = PeriodSalesReport(
                    startDate = startDate,
                    endDate = endDate,
                    salesByMonth = salesByMonth,
                    monthlyTotals = monthlyTotals
                )
                
                _periodSalesReport.value = report
                _state.value = ReportsState.Success
            } catch (e: Exception) {
                _state.value = ReportsState.Error("حدث خطأ أثناء إنشاء تقرير المبيعات حسب الفترة: ${e.message}")
            }
        }
    }
}

sealed class ReportsState {
    object Loading : ReportsState()
    object Success : ReportsState()
    data class Error(val message: String) : ReportsState()
}

data class TotalSalesReport(
    val startDate: Date,
    val endDate: Date,
    val totalSalesAmount: Double,
    val totalCollections: Double,
    val totalDues: Double,
    val sales: List<Sale>
)

data class BuildingSalesReport(
    val building: Building,
    val totalSalesAmount: Double,
    val totalCollections: Double,
    val totalDues: Double,
    val sales: List<Sale>
)

data class PeriodSalesReport(
    val startDate: Date,
    val endDate: Date,
    val salesByMonth: Map<String, List<Sale>>,
    val monthlyTotals: Map<String, Double>
)
