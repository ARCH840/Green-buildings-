package com.greenbuildings.app.ui.sales

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.greenbuildings.app.database.entities.Apartment
import com.greenbuildings.app.database.entities.Buyer
import com.greenbuildings.app.database.entities.Sale
import com.greenbuildings.app.repository.ApartmentRepository
import com.greenbuildings.app.repository.BuyerRepository
import com.greenbuildings.app.repository.SaleRepository
import kotlinx.coroutines.launch
import java.util.Date

class SalesViewModel(
    private val saleRepository: SaleRepository,
    private val buyerRepository: BuyerRepository,
    private val apartmentRepository: ApartmentRepository
) : ViewModel() {
    
    private val _sales = MutableLiveData<List<Sale>>()
    val sales: LiveData<List<Sale>> = _sales
    
    private val _state = MutableLiveData<SalesState>()
    val state: LiveData<SalesState> = _state
    
    private val _currentSale = MutableLiveData<Sale>()
    val currentSale: LiveData<Sale> = _currentSale
    
    init {
        loadSales()
    }
    
    fun loadSales() {
        viewModelScope.launch {
            try {
                _state.value = SalesState.Loading
                val salesList = saleRepository.getAllSales()
                _sales.value = salesList
                _state.value = SalesState.Success
            } catch (e: Exception) {
                _state.value = SalesState.Error("حدث خطأ أثناء تحميل المبيعات: ${e.message}")
            }
        }
    }
    
    fun getSaleById(saleId: Long) {
        viewModelScope.launch {
            try {
                _state.value = SalesState.Loading
                val sale = saleRepository.getSaleById(saleId)
                if (sale != null) {
                    _currentSale.value = sale
                    _state.value = SalesState.Success
                } else {
                    _state.value = SalesState.Error("لم يتم العثور على عملية البيع")
                }
            } catch (e: Exception) {
                _state.value = SalesState.Error("حدث خطأ أثناء تحميل بيانات البيع: ${e.message}")
            }
        }
    }
    
    fun createSale(
        apartmentId: Long,
        buyerName: String,
        buyerPhone: String,
        buyerIdImagePath: String?,
        paymentType: String,
        downPaymentPercentage: Double?,
        downPaymentDate: Date?,
        downPaymentReceiptPath: String?,
        installmentType: String?,
        installmentPeriod: Int?,
        installmentFrequency: String?
    ) {
        viewModelScope.launch {
            try {
                _state.value = SalesState.Loading
                
                // Get apartment details
                val apartment = apartmentRepository.getApartmentById(apartmentId)
                    ?: throw IllegalArgumentException("الشقة غير موجودة")
                
                // Create buyer
                val buyerId = buyerRepository.insertBuyer(
                    name = buyerName,
                    phone = buyerPhone,
                    idImagePath = buyerIdImagePath
                )
                
                // Calculate down payment amount
                val downPaymentAmount = if (paymentType == "installments" && downPaymentPercentage != null) {
                    apartment.totalPrice * (downPaymentPercentage / 100.0)
                } else if (paymentType == "cash") {
                    apartment.totalPrice
                } else {
                    null
                }
                
                // Create sale
                val saleId = saleRepository.createSale(
                    apartmentId = apartmentId,
                    buyerId = buyerId,
                    paymentType = paymentType,
                    downPaymentPercentage = downPaymentPercentage,
                    downPaymentAmount = downPaymentAmount,
                    downPaymentDate = downPaymentDate,
                    downPaymentStatus = if (downPaymentAmount != null) "paid" else null,
                    downPaymentReceiptPath = downPaymentReceiptPath,
                    installmentType = installmentType,
                    installmentPeriod = installmentPeriod,
                    installmentFrequency = installmentFrequency
                )
                
                // Load the created sale
                getSaleById(saleId)
                
                // Refresh sales list
                loadSales()
                
                _state.value = SalesState.Success
            } catch (e: Exception) {
                _state.value = SalesState.Error("حدث خطأ أثناء إنشاء عملية البيع: ${e.message}")
            }
        }
    }
    
    fun updateSale(sale: Sale) {
        viewModelScope.launch {
            try {
                _state.value = SalesState.Loading
                saleRepository.updateSale(sale)
                _currentSale.value = sale
                loadSales()
                _state.value = SalesState.Success
            } catch (e: Exception) {
                _state.value = SalesState.Error("حدث خطأ أثناء تحديث عملية البيع: ${e.message}")
            }
        }
    }
}

sealed class SalesState {
    object Loading : SalesState()
    object Success : SalesState()
    data class Error(val message: String) : SalesState()
}
