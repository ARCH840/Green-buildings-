package com.constructionmanager.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ProgressBar;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.constructionmanager.app.R;
import com.constructionmanager.app.data.entities.WorkProgress;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class WorkProgressAdapter extends RecyclerView.Adapter<WorkProgressAdapter.WorkProgressViewHolder> {

    private List<WorkProgress> workProgressList;
    private OnItemClickListener listener;

    public WorkProgressAdapter(List<WorkProgress> workProgressList) {
        this.workProgressList = workProgressList;
    }

    @NonNull
    @Override
    public WorkProgressViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_work_progress, parent, false);
        return new WorkProgressViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull WorkProgressViewHolder holder, int position) {
        WorkProgress currentWorkProgress = workProgressList.get(position);
        holder.tvWorkTitle.setText(currentWorkProgress.getWorkTitle());
        holder.tvContractTitle.setText(currentWorkProgress.getContractTitle());
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String recordDate = currentWorkProgress.getRecordDate() != null ? 
                dateFormat.format(currentWorkProgress.getRecordDate()) : "غير محدد";
        
        holder.tvRecordDate.setText("تاريخ التسجيل: " + recordDate);
        holder.tvQuantityCompleted.setText(String.format("الكمية المنجزة: %s %s", 
                currentWorkProgress.getQuantityCompleted(), 
                currentWorkProgress.getUnit()));
        
        // تعيين نسبة الإنجاز
        int progressPercentage = (int) currentWorkProgress.getProgressPercentage();
        holder.progressBar.setProgress(progressPercentage);
        holder.tvProgressPercentage.setText(progressPercentage + "%");
    }

    @Override
    public int getItemCount() {
        return workProgressList.size();
    }

    public void setWorkProgressList(List<WorkProgress> workProgressList) {
        this.workProgressList = workProgressList;
        notifyDataSetChanged();
    }

    public class WorkProgressViewHolder extends RecyclerView.ViewHolder {
        private TextView tvWorkTitle;
        private TextView tvContractTitle;
        private TextView tvRecordDate;
        private TextView tvQuantityCompleted;
        private ProgressBar progressBar;
        private TextView tvProgressPercentage;

        public WorkProgressViewHolder(View itemView) {
            super(itemView);
            tvWorkTitle = itemView.findViewById(R.id.tv_work_title);
            tvContractTitle = itemView.findViewById(R.id.tv_contract_title);
            tvRecordDate = itemView.findViewById(R.id.tv_record_date);
            tvQuantityCompleted = itemView.findViewById(R.id.tv_quantity_completed);
            progressBar = itemView.findViewById(R.id.progress_bar);
            tvProgressPercentage = itemView.findViewById(R.id.tv_progress_percentage);
            
            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(workProgressList.get(position));
                }
            });
        }
    }

    public interface OnItemClickListener {
        void onItemClick(WorkProgress workProgress);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }
}
