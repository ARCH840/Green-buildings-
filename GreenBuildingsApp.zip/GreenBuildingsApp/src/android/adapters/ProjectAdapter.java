package com.constructionmanager.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.constructionmanager.app.R;
import com.constructionmanager.app.data.entities.Project;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class ProjectAdapter extends RecyclerView.Adapter<ProjectAdapter.ProjectViewHolder> {

    private List<Project> projects;
    private OnItemClickListener listener;

    public ProjectAdapter(List<Project> projects) {
        this.projects = projects;
    }

    @NonNull
    @Override
    public ProjectViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_project, parent, false);
        return new ProjectViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ProjectViewHolder holder, int position) {
        Project currentProject = projects.get(position);
        holder.tvProjectName.setText(currentProject.getName());
        holder.tvProjectLocation.setText(currentProject.getLocation());
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String startDate = currentProject.getStartDate() != null ? 
                dateFormat.format(currentProject.getStartDate()) : "غير محدد";
        String endDate = currentProject.getEndDate() != null ? 
                dateFormat.format(currentProject.getEndDate()) : "غير محدد";
        
        holder.tvProjectDates.setText("من " + startDate + " إلى " + endDate);
        holder.tvProjectStatus.setText(currentProject.getStatus());
        
        // تعيين لون حالة المشروع
        if ("مكتمل".equals(currentProject.getStatus())) {
            holder.tvProjectStatus.setBackgroundResource(R.drawable.status_completed);
        } else if ("قيد التنفيذ".equals(currentProject.getStatus())) {
            holder.tvProjectStatus.setBackgroundResource(R.drawable.status_in_progress);
        } else if ("متوقف".equals(currentProject.getStatus())) {
            holder.tvProjectStatus.setBackgroundResource(R.drawable.status_on_hold);
        } else {
            holder.tvProjectStatus.setBackgroundResource(R.drawable.status_default);
        }
    }

    @Override
    public int getItemCount() {
        return projects.size();
    }

    public void setProjects(List<Project> projects) {
        this.projects = projects;
        notifyDataSetChanged();
    }

    public class ProjectViewHolder extends RecyclerView.ViewHolder {
        private TextView tvProjectName;
        private TextView tvProjectLocation;
        private TextView tvProjectDates;
        private TextView tvProjectStatus;

        public ProjectViewHolder(View itemView) {
            super(itemView);
            tvProjectName = itemView.findViewById(R.id.tv_project_name);
            tvProjectLocation = itemView.findViewById(R.id.tv_project_location);
            tvProjectDates = itemView.findViewById(R.id.tv_project_dates);
            tvProjectStatus = itemView.findViewById(R.id.tv_project_status);
            
            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(projects.get(position));
                }
            });
        }
    }

    public interface OnItemClickListener {
        void onItemClick(Project project);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }
}
