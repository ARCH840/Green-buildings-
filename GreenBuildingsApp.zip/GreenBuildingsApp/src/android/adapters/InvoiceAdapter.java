package com.constructionmanager.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.constructionmanager.app.R;
import com.constructionmanager.app.data.entities.Invoice;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class InvoiceAdapter extends RecyclerView.Adapter<InvoiceAdapter.InvoiceViewHolder> {

    private List<Invoice> invoices;
    private OnItemClickListener listener;

    public InvoiceAdapter(List<Invoice> invoices) {
        this.invoices = invoices;
    }

    @NonNull
    @Override
    public InvoiceViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_invoice, parent, false);
        return new InvoiceViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull InvoiceViewHolder holder, int position) {
        Invoice currentInvoice = invoices.get(position);
        holder.tvInvoiceNumber.setText("مستخلص رقم: " + currentInvoice.getInvoiceNumber());
        holder.tvContractTitle.setText(currentInvoice.getContractTitle());
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String issueDate = currentInvoice.getIssueDate() != null ? 
                dateFormat.format(currentInvoice.getIssueDate()) : "غير محدد";
        String dueDate = currentInvoice.getDueDate() != null ? 
                dateFormat.format(currentInvoice.getDueDate()) : "غير محدد";
        
        holder.tvIssueDueDate.setText("تاريخ الإصدار: " + issueDate + " | تاريخ الاستحقاق: " + dueDate);
        holder.tvAmount.setText(String.format("%,.0f ريال", currentInvoice.getAmount()));
        holder.tvStatus.setText(currentInvoice.getStatus());
        
        // تعيين لون حالة المستخلص
        if ("مدفوع".equals(currentInvoice.getStatus())) {
            holder.tvStatus.setBackgroundResource(R.drawable.status_completed);
        } else if ("قيد المراجعة".equals(currentInvoice.getStatus())) {
            holder.tvStatus.setBackgroundResource(R.drawable.status_in_progress);
        } else if ("متأخر".equals(currentInvoice.getStatus())) {
            holder.tvStatus.setBackgroundResource(R.drawable.status_on_hold);
        } else {
            holder.tvStatus.setBackgroundResource(R.drawable.status_default);
        }
    }

    @Override
    public int getItemCount() {
        return invoices.size();
    }

    public void setInvoices(List<Invoice> invoices) {
        this.invoices = invoices;
        notifyDataSetChanged();
    }

    public class InvoiceViewHolder extends RecyclerView.ViewHolder {
        private TextView tvInvoiceNumber;
        private TextView tvContractTitle;
        private TextView tvIssueDueDate;
        private TextView tvAmount;
        private TextView tvStatus;

        public InvoiceViewHolder(View itemView) {
            super(itemView);
            tvInvoiceNumber = itemView.findViewById(R.id.tv_invoice_number);
            tvContractTitle = itemView.findViewById(R.id.tv_contract_title);
            tvIssueDueDate = itemView.findViewById(R.id.tv_issue_due_date);
            tvAmount = itemView.findViewById(R.id.tv_amount);
            tvStatus = itemView.findViewById(R.id.tv_status);
            
            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(invoices.get(position));
                }
            });
        }
    }

    public interface OnItemClickListener {
        void onItemClick(Invoice invoice);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }
}
