package com.constructionmanager.app.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.constructionmanager.app.R;
import com.constructionmanager.app.data.entities.Contract;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class ContractAdapter extends RecyclerView.Adapter<ContractAdapter.ContractViewHolder> {

    private List<Contract> contracts;
    private OnItemClickListener listener;

    public ContractAdapter(List<Contract> contracts) {
        this.contracts = contracts;
    }

    @NonNull
    @Override
    public ContractViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_contract, parent, false);
        return new ContractViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull ContractViewHolder holder, int position) {
        Contract currentContract = contracts.get(position);
        holder.tvContractTitle.setText(currentContract.getTitle());
        holder.tvContractorName.setText(currentContract.getContractorName());
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        String startDate = currentContract.getStartDate() != null ? 
                dateFormat.format(currentContract.getStartDate()) : "غير محدد";
        String endDate = currentContract.getEndDate() != null ? 
                dateFormat.format(currentContract.getEndDate()) : "غير محدد";
        
        holder.tvContractDates.setText("من " + startDate + " إلى " + endDate);
        holder.tvContractValue.setText(String.format("%,.0f ريال", currentContract.getValue()));
        holder.tvContractStatus.setText(currentContract.getStatus());
        
        // تعيين لون حالة العقد
        if ("مكتمل".equals(currentContract.getStatus())) {
            holder.tvContractStatus.setBackgroundResource(R.drawable.status_completed);
        } else if ("نشط".equals(currentContract.getStatus())) {
            holder.tvContractStatus.setBackgroundResource(R.drawable.status_in_progress);
        } else if ("متوقف".equals(currentContract.getStatus())) {
            holder.tvContractStatus.setBackgroundResource(R.drawable.status_on_hold);
        } else {
            holder.tvContractStatus.setBackgroundResource(R.drawable.status_default);
        }
    }

    @Override
    public int getItemCount() {
        return contracts.size();
    }

    public void setContracts(List<Contract> contracts) {
        this.contracts = contracts;
        notifyDataSetChanged();
    }

    public class ContractViewHolder extends RecyclerView.ViewHolder {
        private TextView tvContractTitle;
        private TextView tvContractorName;
        private TextView tvContractDates;
        private TextView tvContractValue;
        private TextView tvContractStatus;

        public ContractViewHolder(View itemView) {
            super(itemView);
            tvContractTitle = itemView.findViewById(R.id.tv_contract_title);
            tvContractorName = itemView.findViewById(R.id.tv_contractor_name);
            tvContractDates = itemView.findViewById(R.id.tv_contract_dates);
            tvContractValue = itemView.findViewById(R.id.tv_contract_value);
            tvContractStatus = itemView.findViewById(R.id.tv_contract_status);
            
            itemView.setOnClickListener(v -> {
                int position = getAdapterPosition();
                if (listener != null && position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(contracts.get(position));
                }
            });
        }
    }

    public interface OnItemClickListener {
        void onItemClick(Contract contract);
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }
}
