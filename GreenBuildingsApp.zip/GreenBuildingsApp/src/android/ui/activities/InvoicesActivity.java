package com.constructionmanager.app.ui.activities;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.constructionmanager.app.R;
import com.constructionmanager.app.adapters.InvoiceAdapter;
import com.constructionmanager.app.data.entities.Contract;
import com.constructionmanager.app.data.entities.Invoice;
import com.constructionmanager.app.viewmodels.ContractViewModel;
import com.constructionmanager.app.viewmodels.InvoiceViewModel;
import com.constructionmanager.app.viewmodels.PaymentViewModel;

import java.util.ArrayList;
import java.util.List;

public class InvoicesActivity extends AppCompatActivity {

    private InvoiceViewModel invoiceViewModel;
    private PaymentViewModel paymentViewModel;
    private ContractViewModel contractViewModel;
    private RecyclerView recyclerView;
    private InvoiceAdapter adapter;
    private TextView tvNoInvoices;
    private TextView tvTotalInvoices;
    private TextView tvInvoicesValue;
    private TextView tvPaymentsValue;
    private Spinner spinnerContracts;
    private long projectId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoices);

        // استلام معرف المشروع من النية
        projectId = getIntent().getLongExtra("PROJECT_ID", -1);
        if (projectId == -1) {
            finish();
            return;
        }

        // إعداد شريط الأدوات
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("المستخلصات والمدفوعات");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // تهيئة العناصر
        recyclerView = findViewById(R.id.rv_invoices);
        tvNoInvoices = findViewById(R.id.tv_no_invoices);
        tvTotalInvoices = findViewById(R.id.tv_total_invoices);
        tvInvoicesValue = findViewById(R.id.tv_invoices_value);
        tvPaymentsValue = findViewById(R.id.tv_payments_value);
        spinnerContracts = findViewById(R.id.spinner_contracts);

        // إعداد RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new InvoiceAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        // إعداد ViewModels
        invoiceViewModel = new ViewModelProvider(this).get(InvoiceViewModel.class);
        paymentViewModel = new ViewModelProvider(this).get(PaymentViewModel.class);
        contractViewModel = new ViewModelProvider(this).get(ContractViewModel.class);
        
        // إعداد قائمة العقود في السبينر
        setupContractsSpinner();
        
        // مراقبة التغييرات في قائمة المستخلصات
        invoiceViewModel.getInvoicesByProject(projectId).observe(this, invoices -> {
            if (invoices != null && !invoices.isEmpty()) {
                adapter.setInvoices(invoices);
                tvNoInvoices.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);
                
                // تحديث ملخص المستخلصات
                updateInvoicesSummary(invoices);
            } else {
                tvNoInvoices.setVisibility(View.VISIBLE);
                recyclerView.setVisibility(View.GONE);
                
                // تصفير ملخص المستخلصات
                tvTotalInvoices.setText("0");
                tvInvoicesValue.setText("0 ريال");
                tvPaymentsValue.setText("0 ريال");
            }
        });

        // إعداد زر إضافة مستخلص جديد
        findViewById(R.id.btn_add_invoice).setOnClickListener(v -> {
            // فتح نافذة إضافة مستخلص جديد
            // سيتم تنفيذها لاحقاً
            showAddInvoiceDialog();
        });

        // إعداد معالج النقر على عنصر المستخلص
        adapter.setOnItemClickListener(invoice -> {
            // فتح تفاصيل المستخلص
            // سيتم تنفيذها لاحقاً
            showInvoiceDetails(invoice);
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupContractsSpinner() {
        contractViewModel.getContractsByProject(projectId).observe(this, contracts -> {
            if (contracts != null && !contracts.isEmpty()) {
                List<String> contractNames = new ArrayList<>();
                contractNames.add("جميع العقود");
                
                for (Contract contract : contracts) {
                    contractNames.add(contract.getTitle());
                }
                
                ArrayAdapter<String> adapter = new ArrayAdapter<>(
                        this, android.R.layout.simple_spinner_item, contractNames);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerContracts.setAdapter(adapter);
                
                // إعداد معالج تغيير العقد المحدد
                spinnerContracts.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                        if (position == 0) {
                            // عرض جميع المستخلصات
                            invoiceViewModel.getInvoicesByProject(projectId).observe(InvoicesActivity.this, invoices -> {
                                adapter.setInvoices(invoices);
                                updateInvoicesSummary(invoices);
                            });
                        } else {
                            // عرض المستخلصات حسب العقد المحدد
                            Contract selectedContract = contracts.get(position - 1);
                            invoiceViewModel.getInvoicesByContract(selectedContract.getId()).observe(InvoicesActivity.this, invoices -> {
                                adapter.setInvoices(invoices);
                                updateInvoicesSummary(invoices);
                            });
                        }
                    }

                    @Override
                    public void onNothingSelected(android.widget.AdapterView<?> parent) {
                        // لا شيء
                    }
                });
            }
        });
    }

    private void updateInvoicesSummary(List<Invoice> invoices) {
        int totalInvoices = invoices.size();
        double totalInvoicesValue = 0;
        
        for (Invoice invoice : invoices) {
            totalInvoicesValue += invoice.getAmount();
        }
        
        tvTotalInvoices.setText(String.valueOf(totalInvoices));
        tvInvoicesValue.setText(String.format("%,.0f ريال", totalInvoicesValue));
        
        // الحصول على إجمالي المدفوعات
        paymentViewModel.getTotalPaymentsByProject(projectId).observe(this, totalPayments -> {
            if (totalPayments != null) {
                tvPaymentsValue.setText(String.format("%,.0f ريال", totalPayments));
            } else {
                tvPaymentsValue.setText("0 ريال");
            }
        });
    }

    private void showAddInvoiceDialog() {
        // سيتم تنفيذ هذه الدالة لاحقاً لإضافة مستخلص جديد
        // يمكن استخدام AlertDialog أو نافذة مخصصة
    }

    private void showInvoiceDetails(Invoice invoice) {
        // سيتم تنفيذ هذه الدالة لاحقاً لعرض تفاصيل المستخلص
        // يمكن استخدام AlertDialog أو نافذة مخصصة
    }
}
