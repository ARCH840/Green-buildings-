package com.constructionmanager.app.ui.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.constructionmanager.app.R;
import com.constructionmanager.app.adapters.ProjectAdapter;
import com.constructionmanager.app.data.entities.Project;
import com.constructionmanager.app.viewmodels.ProjectViewModel;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ProjectViewModel projectViewModel;
    private RecyclerView recyclerView;
    private ProjectAdapter adapter;
    private TextView tvNoProjects;
    private FloatingActionButton fabAddProject;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // إعداد شريط الأدوات
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("مشاريع البناء");

        // تهيئة العناصر
        recyclerView = findViewById(R.id.rv_projects);
        tvNoProjects = findViewById(R.id.tv_no_projects);
        fabAddProject = findViewById(R.id.fab_add_project);

        // إعداد RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ProjectAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        // إعداد ViewModel
        projectViewModel = new ViewModelProvider(this).get(ProjectViewModel.class);
        
        // مراقبة التغييرات في قائمة المشاريع
        projectViewModel.getAllProjects().observe(this, projects -> {
            if (projects != null && !projects.isEmpty()) {
                adapter.setProjects(projects);
                tvNoProjects.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);
            } else {
                tvNoProjects.setVisibility(View.VISIBLE);
                recyclerView.setVisibility(View.GONE);
            }
        });

        // إعداد زر إضافة مشروع جديد
        fabAddProject.setOnClickListener(v -> {
            // فتح نافذة إضافة مشروع جديد
            // سيتم تنفيذها لاحقاً
            showAddProjectDialog();
        });

        // إعداد معالج النقر على عنصر المشروع
        adapter.setOnItemClickListener(project -> {
            Intent intent = new Intent(MainActivity.this, ProjectDetailsActivity.class);
            intent.putExtra("PROJECT_ID", project.getId());
            startActivity(intent);
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        
        // سيتم تنفيذ معالجات الخيارات لاحقاً
        
        return super.onOptionsItemSelected(item);
    }

    private void showAddProjectDialog() {
        // سيتم تنفيذ هذه الدالة لاحقاً لإضافة مشروع جديد
        // يمكن استخدام AlertDialog أو نافذة مخصصة
    }
}
