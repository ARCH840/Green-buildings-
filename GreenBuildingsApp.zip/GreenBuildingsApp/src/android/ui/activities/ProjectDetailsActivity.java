package com.constructionmanager.app.ui.activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.lifecycle.ViewModelProvider;

import com.constructionmanager.app.R;
import com.constructionmanager.app.data.entities.Project;
import com.constructionmanager.app.viewmodels.ContractViewModel;
import com.constructionmanager.app.viewmodels.InvoiceViewModel;
import com.constructionmanager.app.viewmodels.ProjectViewModel;
import com.constructionmanager.app.viewmodels.WorkProgressViewModel;

public class ProjectDetailsActivity extends AppCompatActivity {

    private ProjectViewModel projectViewModel;
    private ContractViewModel contractViewModel;
    private WorkProgressViewModel workProgressViewModel;
    private InvoiceViewModel invoiceViewModel;
    private long projectId;
    private Project currentProject;

    // عناصر واجهة المستخدم
    private TextView tvProjectTitle;
    private TextView tvProjectLocation;
    private TextView tvProjectDates;
    private TextView tvProjectStatus;
    private TextView tvProjectBudget;
    private TextView tvProjectExpenses;
    private TextView tvProjectProgress;
    private CardView cardContracts;
    private CardView cardWorkProgress;
    private CardView cardInvoices;
    private CardView cardReports;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_project_details);

        // استلام معرف المشروع من النية
        projectId = getIntent().getLongExtra("PROJECT_ID", -1);
        if (projectId == -1) {
            finish();
            return;
        }

        // إعداد شريط الأدوات
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("تفاصيل المشروع");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // تهيئة عناصر واجهة المستخدم
        initializeViews();

        // إعداد ViewModels
        projectViewModel = new ViewModelProvider(this).get(ProjectViewModel.class);
        contractViewModel = new ViewModelProvider(this).get(ContractViewModel.class);
        workProgressViewModel = new ViewModelProvider(this).get(WorkProgressViewModel.class);
        invoiceViewModel = new ViewModelProvider(this).get(InvoiceViewModel.class);

        // تحميل بيانات المشروع
        loadProjectData();

        // إعداد معالجات النقر على البطاقات
        setupCardClickListeners();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void initializeViews() {
        tvProjectTitle = findViewById(R.id.tv_project_title);
        tvProjectLocation = findViewById(R.id.tv_project_location);
        tvProjectDates = findViewById(R.id.tv_project_dates);
        tvProjectStatus = findViewById(R.id.tv_project_status);
        tvProjectBudget = findViewById(R.id.tv_project_budget);
        tvProjectExpenses = findViewById(R.id.tv_project_expenses);
        tvProjectProgress = findViewById(R.id.tv_project_progress);
        cardContracts = findViewById(R.id.card_contracts);
        cardWorkProgress = findViewById(R.id.card_work_progress);
        cardInvoices = findViewById(R.id.card_invoices);
        cardReports = findViewById(R.id.card_reports);
    }

    private void loadProjectData() {
        projectViewModel.getProjectById(projectId).observe(this, project -> {
            if (project != null) {
                currentProject = project;
                updateProjectUI(project);
            } else {
                // المشروع غير موجود، إغلاق النشاط
                finish();
            }
        });

        // تحميل ملخص المستخلصات
        invoiceViewModel.getTotalInvoiceAmountByProject(projectId).observe(this, totalAmount -> {
            if (totalAmount != null) {
                tvProjectExpenses.setText(String.format("%,.0f ريال", totalAmount));
            } else {
                tvProjectExpenses.setText("0 ريال");
            }
        });

        // تحميل نسبة تقدم المشروع
        workProgressViewModel.getAverageProgressByProject(projectId).observe(this, averageProgress -> {
            if (averageProgress != null) {
                tvProjectProgress.setText(String.format("%.0f%%", averageProgress));
            } else {
                tvProjectProgress.setText("0%");
            }
        });
    }

    private void updateProjectUI(Project project) {
        tvProjectTitle.setText(project.getName());
        tvProjectLocation.setText("الموقع: " + project.getLocation());
        tvProjectDates.setText("تاريخ البدء: " + formatDate(project.getStartDate()) + 
                " - تاريخ الانتهاء المتوقع: " + formatDate(project.getEndDate()));
        tvProjectStatus.setText(project.getStatus());
        tvProjectBudget.setText(String.format("%,.0f ريال", project.getBudget()));
    }

    private String formatDate(java.util.Date date) {
        if (date == null) return "غير محدد";
        java.text.SimpleDateFormat sdf = new java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault());
        return sdf.format(date);
    }

    private void setupCardClickListeners() {
        // بطاقة العقود
        cardContracts.setOnClickListener(v -> {
            Intent intent = new Intent(ProjectDetailsActivity.this, ContractsActivity.class);
            intent.putExtra("PROJECT_ID", projectId);
            startActivity(intent);
        });

        // بطاقة حصر الأعمال
        cardWorkProgress.setOnClickListener(v -> {
            Intent intent = new Intent(ProjectDetailsActivity.this, WorkProgressActivity.class);
            intent.putExtra("PROJECT_ID", projectId);
            startActivity(intent);
        });

        // بطاقة المستخلصات
        cardInvoices.setOnClickListener(v -> {
            Intent intent = new Intent(ProjectDetailsActivity.this, InvoicesActivity.class);
            intent.putExtra("PROJECT_ID", projectId);
            startActivity(intent);
        });

        // بطاقة التقارير
        cardReports.setOnClickListener(v -> {
            Intent intent = new Intent(ProjectDetailsActivity.this, ReportsActivity.class);
            intent.putExtra("PROJECT_ID", projectId);
            startActivity(intent);
        });
    }
}
