package com.constructionmanager.app.ui.activities;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.constructionmanager.app.R;
import com.constructionmanager.app.adapters.WorkProgressAdapter;
import com.constructionmanager.app.data.entities.Contract;
import com.constructionmanager.app.data.entities.WorkProgress;
import com.constructionmanager.app.viewmodels.ContractViewModel;
import com.constructionmanager.app.viewmodels.WorkProgressViewModel;

import java.util.ArrayList;
import java.util.List;

public class WorkProgressActivity extends AppCompatActivity {

    private WorkProgressViewModel workProgressViewModel;
    private ContractViewModel contractViewModel;
    private RecyclerView recyclerView;
    private WorkProgressAdapter adapter;
    private TextView tvNoWorks;
    private TextView tvTotalWorks;
    private TextView tvCompletedWorks;
    private TextView tvWorkProgress;
    private Spinner spinnerContracts;
    private long projectId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_progress);

        // استلام معرف المشروع من النية
        projectId = getIntent().getLongExtra("PROJECT_ID", -1);
        if (projectId == -1) {
            finish();
            return;
        }

        // إعداد شريط الأدوات
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("حصر الأعمال");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // تهيئة العناصر
        recyclerView = findViewById(R.id.rv_works);
        tvNoWorks = findViewById(R.id.tv_no_works);
        tvTotalWorks = findViewById(R.id.tv_total_works);
        tvCompletedWorks = findViewById(R.id.tv_completed_works);
        tvWorkProgress = findViewById(R.id.tv_work_progress);
        spinnerContracts = findViewById(R.id.spinner_contracts);

        // إعداد RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WorkProgressAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        // إعداد ViewModels
        workProgressViewModel = new ViewModelProvider(this).get(WorkProgressViewModel.class);
        contractViewModel = new ViewModelProvider(this).get(ContractViewModel.class);
        
        // إعداد قائمة العقود في السبينر
        setupContractsSpinner();
        
        // مراقبة التغييرات في قائمة الأعمال
        workProgressViewModel.getWorkProgressByProject(projectId).observe(this, workProgressList -> {
            if (workProgressList != null && !workProgressList.isEmpty()) {
                adapter.setWorkProgressList(workProgressList);
                tvNoWorks.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);
                
                // تحديث ملخص الأعمال
                updateWorkSummary(workProgressList);
            } else {
                tvNoWorks.setVisibility(View.VISIBLE);
                recyclerView.setVisibility(View.GONE);
                
                // تصفير ملخص الأعمال
                tvTotalWorks.setText("0");
                tvCompletedWorks.setText("0");
                tvWorkProgress.setText("0%");
            }
        });

        // إعداد زر إضافة عمل جديد
        findViewById(R.id.btn_add_work).setOnClickListener(v -> {
            // فتح نافذة إضافة عمل جديد
            // سيتم تنفيذها لاحقاً
            showAddWorkDialog();
        });

        // إعداد معالج النقر على عنصر العمل
        adapter.setOnItemClickListener(workProgress -> {
            // فتح تفاصيل العمل
            // سيتم تنفيذها لاحقاً
            showWorkDetails(workProgress);
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupContractsSpinner() {
        contractViewModel.getContractsByProject(projectId).observe(this, contracts -> {
            if (contracts != null && !contracts.isEmpty()) {
                List<String> contractNames = new ArrayList<>();
                contractNames.add("جميع العقود");
                
                for (Contract contract : contracts) {
                    contractNames.add(contract.getTitle());
                }
                
                ArrayAdapter<String> adapter = new ArrayAdapter<>(
                        this, android.R.layout.simple_spinner_item, contractNames);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerContracts.setAdapter(adapter);
                
                // إعداد معالج تغيير العقد المحدد
                spinnerContracts.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                        if (position == 0) {
                            // عرض جميع الأعمال
                            workProgressViewModel.getWorkProgressByProject(projectId).observe(WorkProgressActivity.this, workProgressList -> {
                                adapter.setWorkProgressList(workProgressList);
                                updateWorkSummary(workProgressList);
                            });
                        } else {
                            // عرض الأعمال حسب العقد المحدد
                            Contract selectedContract = contracts.get(position - 1);
                            workProgressViewModel.getWorkProgressByContract(selectedContract.getId()).observe(WorkProgressActivity.this, workProgressList -> {
                                adapter.setWorkProgressList(workProgressList);
                                updateWorkSummary(workProgressList);
                            });
                        }
                    }

                    @Override
                    public void onNothingSelected(android.widget.AdapterView<?> parent) {
                        // لا شيء
                    }
                });
            }
        });
    }

    private void updateWorkSummary(List<WorkProgress> workProgressList) {
        int totalWorks = workProgressList.size();
        int completedWorks = 0;
        double totalProgress = 0;
        
        for (WorkProgress workProgress : workProgressList) {
            totalProgress += workProgress.getProgressPercentage();
            if (workProgress.getProgressPercentage() == 100) {
                completedWorks++;
            }
        }
        
        double averageProgress = totalWorks > 0 ? totalProgress / totalWorks : 0;
        
        tvTotalWorks.setText(String.valueOf(totalWorks));
        tvCompletedWorks.setText(String.valueOf(completedWorks));
        tvWorkProgress.setText(String.format("%.0f%%", averageProgress));
    }

    private void showAddWorkDialog() {
        // سيتم تنفيذ هذه الدالة لاحقاً لإضافة عمل جديد
        // يمكن استخدام AlertDialog أو نافذة مخصصة
    }

    private void showWorkDetails(WorkProgress workProgress) {
        // سيتم تنفيذ هذه الدالة لاحقاً لعرض تفاصيل العمل
        // يمكن استخدام AlertDialog أو نافذة مخصصة
    }
}
