package com.constructionmanager.app.ui.activities;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.lifecycle.ViewModelProvider;

import com.constructionmanager.app.R;
import com.constructionmanager.app.viewmodels.ProjectViewModel;
import com.constructionmanager.app.viewmodels.ContractViewModel;
import com.constructionmanager.app.viewmodels.WorkProgressViewModel;
import com.constructionmanager.app.viewmodels.InvoiceViewModel;

public class ReportsActivity extends AppCompatActivity {

    private ProjectViewModel projectViewModel;
    private ContractViewModel contractViewModel;
    private WorkProgressViewModel workProgressViewModel;
    private InvoiceViewModel invoiceViewModel;
    private long projectId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reports);

        // استلام معرف المشروع من النية
        projectId = getIntent().getLongExtra("PROJECT_ID", -1);
        if (projectId == -1) {
            finish();
            return;
        }

        // إعداد شريط الأدوات
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("التقارير");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // إعداد ViewModels
        projectViewModel = new ViewModelProvider(this).get(ProjectViewModel.class);
        contractViewModel = new ViewModelProvider(this).get(ContractViewModel.class);
        workProgressViewModel = new ViewModelProvider(this).get(WorkProgressViewModel.class);
        invoiceViewModel = new ViewModelProvider(this).get(InvoiceViewModel.class);

        // إعداد معالجات النقر على بطاقات التقارير
        setupReportCards();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void setupReportCards() {
        // تقرير ملخص المشروع
        CardView cardProjectSummary = findViewById(R.id.card_project_summary);
        cardProjectSummary.setOnClickListener(v -> {
            generateProjectSummaryReport();
        });

        // تقرير تقدم الأعمال
        CardView cardWorkProgress = findViewById(R.id.card_work_progress_report);
        cardWorkProgress.setOnClickListener(v -> {
            generateWorkProgressReport();
        });

        // التقرير المالي
        CardView cardFinancial = findViewById(R.id.card_financial_report);
        cardFinancial.setOnClickListener(v -> {
            generateFinancialReport();
        });

        // تقرير العقود
        CardView cardContracts = findViewById(R.id.card_contracts_report);
        cardContracts.setOnClickListener(v -> {
            generateContractsReport();
        });

        // إنشاء تقرير مخصص
        CardView cardCustom = findViewById(R.id.card_custom_report);
        cardCustom.setOnClickListener(v -> {
            showCustomReportDialog();
        });
    }

    private void generateProjectSummaryReport() {
        // سيتم تنفيذ هذه الدالة لاحقاً لإنشاء تقرير ملخص المشروع
        // يمكن استخدام AlertDialog أو نافذة مخصصة لعرض التقرير
        // أو إنشاء ملف PDF وحفظه
    }

    private void generateWorkProgressReport() {
        // سيتم تنفيذ هذه الدالة لاحقاً لإنشاء تقرير تقدم الأعمال
    }

    private void generateFinancialReport() {
        // سيتم تنفيذ هذه الدالة لاحقاً لإنشاء التقرير المالي
    }

    private void generateContractsReport() {
        // سيتم تنفيذ هذه الدالة لاحقاً لإنشاء تقرير العقود
    }

    private void showCustomReportDialog() {
        // سيتم تنفيذ هذه الدالة لاحقاً لإنشاء تقرير مخصص
        // يمكن استخدام AlertDialog أو نافذة مخصصة لتحديد معايير التقرير
    }
}
