package com.constructionmanager.app.ui.activities;

import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Spinner;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.constructionmanager.app.R;
import com.constructionmanager.app.adapters.ContractAdapter;
import com.constructionmanager.app.data.entities.Contract;
import com.constructionmanager.app.viewmodels.ContractViewModel;
import com.constructionmanager.app.viewmodels.ProjectViewModel;

import java.util.ArrayList;

public class ContractsActivity extends AppCompatActivity {

    private ContractViewModel contractViewModel;
    private ProjectViewModel projectViewModel;
    private RecyclerView recyclerView;
    private ContractAdapter adapter;
    private TextView tvNoContracts;
    private TextView tvTotalContracts;
    private TextView tvContractsValue;
    private TextView tvActiveContracts;
    private long projectId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contracts);

        // استلام معرف المشروع من النية
        projectId = getIntent().getLongExtra("PROJECT_ID", -1);
        if (projectId == -1) {
            finish();
            return;
        }

        // إعداد شريط الأدوات
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setTitle("إدارة العقود");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // تهيئة العناصر
        recyclerView = findViewById(R.id.rv_contracts);
        tvNoContracts = findViewById(R.id.tv_no_contracts);
        tvTotalContracts = findViewById(R.id.tv_total_contracts);
        tvContractsValue = findViewById(R.id.tv_contracts_value);
        tvActiveContracts = findViewById(R.id.tv_active_contracts);

        // إعداد RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ContractAdapter(new ArrayList<>());
        recyclerView.setAdapter(adapter);

        // إعداد ViewModels
        contractViewModel = new ViewModelProvider(this).get(ContractViewModel.class);
        projectViewModel = new ViewModelProvider(this).get(ProjectViewModel.class);
        
        // مراقبة التغييرات في قائمة العقود
        contractViewModel.getContractsByProject(projectId).observe(this, contracts -> {
            if (contracts != null && !contracts.isEmpty()) {
                adapter.setContracts(contracts);
                tvNoContracts.setVisibility(View.GONE);
                recyclerView.setVisibility(View.VISIBLE);
                
                // تحديث ملخص العقود
                updateContractsSummary(contracts);
            } else {
                tvNoContracts.setVisibility(View.VISIBLE);
                recyclerView.setVisibility(View.GONE);
                
                // تصفير ملخص العقود
                tvTotalContracts.setText("0");
                tvContractsValue.setText("0 ريال");
                tvActiveContracts.setText("0");
            }
        });

        // إعداد زر إضافة عقد جديد
        findViewById(R.id.btn_add_contract).setOnClickListener(v -> {
            // فتح نافذة إضافة عقد جديد
            // سيتم تنفيذها لاحقاً
            showAddContractDialog();
        });

        // إعداد معالج النقر على عنصر العقد
        adapter.setOnItemClickListener(contract -> {
            // فتح تفاصيل العقد
            // سيتم تنفيذها لاحقاً
            showContractDetails(contract);
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void updateContractsSummary(java.util.List<Contract> contracts) {
        int totalContracts = contracts.size();
        double totalValue = 0;
        int activeContracts = 0;
        
        for (Contract contract : contracts) {
            totalValue += contract.getValue();
            if (contract.getStatus().equals("نشط")) {
                activeContracts++;
            }
        }
        
        tvTotalContracts.setText(String.valueOf(totalContracts));
        tvContractsValue.setText(String.format("%,.0f ريال", totalValue));
        tvActiveContracts.setText(String.valueOf(activeContracts));
    }

    private void showAddContractDialog() {
        // سيتم تنفيذ هذه الدالة لاحقاً لإضافة عقد جديد
        // يمكن استخدام AlertDialog أو نافذة مخصصة
    }

    private void showContractDetails(Contract contract) {
        // سيتم تنفيذ هذه الدالة لاحقاً لعرض تفاصيل العقد
        // يمكن استخدام AlertDialog أو نافذة مخصصة
    }
}
