package com.constructionmanager.app.data;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

import com.constructionmanager.app.data.converters.DateConverter;
import com.constructionmanager.app.data.dao.ContractDao;
import com.constructionmanager.app.data.dao.ContractorDao;
import com.constructionmanager.app.data.dao.InvoiceDao;
import com.constructionmanager.app.data.dao.NotificationDao;
import com.constructionmanager.app.data.dao.PaymentDao;
import com.constructionmanager.app.data.dao.ProjectDao;
import com.constructionmanager.app.data.dao.ResourceDao;
import com.constructionmanager.app.data.dao.TimelineDao;
import com.constructionmanager.app.data.dao.WorkDao;
import com.constructionmanager.app.data.dao.WorkProgressDao;
import com.constructionmanager.app.data.entities.Contract;
import com.constructionmanager.app.data.entities.Contractor;
import com.constructionmanager.app.data.entities.Invoice;
import com.constructionmanager.app.data.entities.Notification;
import com.constructionmanager.app.data.entities.Payment;
import com.constructionmanager.app.data.entities.Project;
import com.constructionmanager.app.data.entities.Resource;
import com.constructionmanager.app.data.entities.Timeline;
import com.constructionmanager.app.data.entities.Work;
import com.constructionmanager.app.data.entities.WorkProgress;

@Database(entities = {
        Project.class,
        Contractor.class,
        Contract.class,
        Work.class,
        WorkProgress.class,
        Invoice.class,
        Payment.class,
        Timeline.class,
        Resource.class,
        Notification.class
}, version = 1, exportSchema = false)
@TypeConverters({DateConverter.class})
public abstract class AppDatabase extends RoomDatabase {
    public abstract ProjectDao projectDao();
    public abstract ContractorDao contractorDao();
    public abstract ContractDao contractDao();
    public abstract WorkDao workDao();
    public abstract WorkProgressDao workProgressDao();
    public abstract InvoiceDao invoiceDao();
    public abstract PaymentDao paymentDao();
    public abstract TimelineDao timelineDao();
    public abstract ResourceDao resourceDao();
    public abstract NotificationDao notificationDao();
}
