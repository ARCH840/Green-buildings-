package com.constructionmanager.app.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.constructionmanager.app.data.entities.WorkProgress;

import java.util.List;
import java.util.Date;

@Dao
public interface WorkProgressDao {
    @Insert
    long insert(WorkProgress workProgress);

    @Update
    void update(WorkProgress workProgress);

    @Delete
    void delete(WorkProgress workProgress);

    @Query("SELECT * FROM work_progress WHERE progress_id = :id")
    LiveData<WorkProgress> getWorkProgressById(long id);

    @Query("SELECT * FROM work_progress WHERE work_id = :workId ORDER BY date DESC")
    LiveData<List<WorkProgress>> getWorkProgressByWork(long workId);

    @Query("SELECT SUM(quantity_completed) FROM work_progress WHERE work_id = :workId")
    LiveData<Double> getTotalCompletedQuantityByWork(long workId);

    @Query("SELECT * FROM work_progress WHERE date BETWEEN :startDate AND :endDate ORDER BY date DESC")
    LiveData<List<WorkProgress>> getWorkProgressByDateRange(Date startDate, Date endDate);
}
