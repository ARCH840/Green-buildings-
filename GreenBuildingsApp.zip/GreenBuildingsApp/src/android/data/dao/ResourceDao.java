package com.constructionmanager.app.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.constructionmanager.app.data.entities.Resource;

import java.util.List;

@Dao
public interface ResourceDao {
    @Insert
    long insert(Resource resource);

    @Update
    void update(Resource resource);

    @Delete
    void delete(Resource resource);

    @Query("SELECT * FROM resources WHERE resource_id = :id")
    LiveData<Resource> getResourceById(long id);

    @Query("SELECT * FROM resources WHERE project_id = :projectId ORDER BY name ASC")
    LiveData<List<Resource>> getResourcesByProject(long projectId);

    @Query("SELECT * FROM resources WHERE type = :type ORDER BY name ASC")
    LiveData<List<Resource>> getResourcesByType(String type);

    @Query("SELECT SUM(cost) FROM resources WHERE project_id = :projectId")
    LiveData<Double> getTotalResourceCostByProject(long projectId);

    @Query("SELECT * FROM resources WHERE name LIKE '%' || :searchQuery || '%' ORDER BY name ASC")
    LiveData<List<Resource>> searchResources(String searchQuery);
}
