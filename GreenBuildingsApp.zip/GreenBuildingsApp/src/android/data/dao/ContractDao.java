package com.constructionmanager.app.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import androidx.room.Transaction;

import com.constructionmanager.app.data.entities.Contract;

import java.util.List;

@Dao
public interface ContractDao {
    @Insert
    long insert(Contract contract);

    @Update
    void update(Contract contract);

    @Delete
    void delete(Contract contract);

    @Query("SELECT * FROM contracts WHERE contract_id = :id")
    LiveData<Contract> getContractById(long id);

    @Query("SELECT * FROM contracts WHERE project_id = :projectId ORDER BY created_at DESC")
    LiveData<List<Contract>> getContractsByProject(long projectId);

    @Query("SELECT * FROM contracts WHERE contractor_id = :contractorId ORDER BY created_at DESC")
    LiveData<List<Contract>> getContractsByContractor(long contractorId);

    @Query("SELECT * FROM contracts WHERE status = :status ORDER BY created_at DESC")
    LiveData<List<Contract>> getContractsByStatus(String status);

    @Query("SELECT * FROM contracts WHERE title LIKE '%' || :searchQuery || '%' ORDER BY created_at DESC")
    LiveData<List<Contract>> searchContracts(String searchQuery);
}
