package com.constructionmanager.app.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.constructionmanager.app.data.entities.Payment;

import java.util.List;
import java.util.Date;

@Dao
public interface PaymentDao {
    @Insert
    long insert(Payment payment);

    @Update
    void update(Payment payment);

    @Delete
    void delete(Payment payment);

    @Query("SELECT * FROM payments WHERE payment_id = :id")
    LiveData<Payment> getPaymentById(long id);

    @Query("SELECT * FROM payments WHERE invoice_id = :invoiceId ORDER BY payment_date DESC")
    LiveData<List<Payment>> getPaymentsByInvoice(long invoiceId);

    @Query("SELECT SUM(amount) FROM payments WHERE invoice_id = :invoiceId")
    LiveData<Double> getTotalPaymentAmountByInvoice(long invoiceId);

    @Query("SELECT * FROM payments WHERE payment_date BETWEEN :startDate AND :endDate ORDER BY payment_date DESC")
    LiveData<List<Payment>> getPaymentsByDateRange(Date startDate, Date endDate);
}
