package com.constructionmanager.app.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.constructionmanager.app.data.entities.Work;

import java.util.List;

@Dao
public interface WorkDao {
    @Insert
    long insert(Work work);

    @Update
    void update(Work work);

    @Delete
    void delete(Work work);

    @Query("SELECT * FROM works WHERE work_id = :id")
    LiveData<Work> getWorkById(long id);

    @Query("SELECT * FROM works WHERE contract_id = :contractId ORDER BY created_at DESC")
    LiveData<List<Work>> getWorksByContract(long contractId);

    @Query("SELECT SUM(total_price) FROM works WHERE contract_id = :contractId")
    LiveData<Double> getTotalWorkValueByContract(long contractId);

    @Query("SELECT * FROM works WHERE description LIKE '%' || :searchQuery || '%' ORDER BY created_at DESC")
    LiveData<List<Work>> searchWorks(String searchQuery);
}
