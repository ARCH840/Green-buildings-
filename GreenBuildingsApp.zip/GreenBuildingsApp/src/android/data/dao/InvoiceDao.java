package com.constructionmanager.app.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.constructionmanager.app.data.entities.Invoice;

import java.util.List;
import java.util.Date;

@Dao
public interface InvoiceDao {
    @Insert
    long insert(Invoice invoice);

    @Update
    void update(Invoice invoice);

    @Delete
    void delete(Invoice invoice);

    @Query("SELECT * FROM invoices WHERE invoice_id = :id")
    LiveData<Invoice> getInvoiceById(long id);

    @Query("SELECT * FROM invoices WHERE contract_id = :contractId ORDER BY date DESC")
    LiveData<List<Invoice>> getInvoicesByContract(long contractId);

    @Query("SELECT * FROM invoices WHERE status = :status ORDER BY date DESC")
    LiveData<List<Invoice>> getInvoicesByStatus(String status);

    @Query("SELECT SUM(amount) FROM invoices WHERE contract_id = :contractId")
    LiveData<Double> getTotalInvoiceAmountByContract(long contractId);

    @Query("SELECT * FROM invoices WHERE date BETWEEN :startDate AND :endDate ORDER BY date DESC")
    LiveData<List<Invoice>> getInvoicesByDateRange(Date startDate, Date endDate);
}
