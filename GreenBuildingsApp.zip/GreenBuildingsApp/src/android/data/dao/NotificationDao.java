package com.constructionmanager.app.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.constructionmanager.app.data.entities.Notification;

import java.util.List;
import java.util.Date;

@Dao
public interface NotificationDao {
    @Insert
    long insert(Notification notification);

    @Update
    void update(Notification notification);

    @Delete
    void delete(Notification notification);

    @Query("SELECT * FROM notifications WHERE notification_id = :id")
    LiveData<Notification> getNotificationById(long id);

    @Query("SELECT * FROM notifications WHERE project_id = :projectId ORDER BY date DESC")
    LiveData<List<Notification>> getNotificationsByProject(long projectId);

    @Query("SELECT * FROM notifications WHERE is_read = 0 ORDER BY date DESC")
    LiveData<List<Notification>> getUnreadNotifications();

    @Query("SELECT * FROM notifications WHERE priority = :priority ORDER BY date DESC")
    LiveData<List<Notification>> getNotificationsByPriority(String priority);

    @Query("SELECT * FROM notifications WHERE date BETWEEN :startDate AND :endDate ORDER BY date DESC")
    LiveData<List<Notification>> getNotificationsByDateRange(Date startDate, Date endDate);

    @Query("UPDATE notifications SET is_read = 1 WHERE notification_id = :id")
    void markNotificationAsRead(long id);

    @Query("UPDATE notifications SET is_read = 1 WHERE project_id = :projectId")
    void markAllProjectNotificationsAsRead(long projectId);
}
