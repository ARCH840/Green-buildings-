package com.constructionmanager.app.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.constructionmanager.app.data.entities.Contractor;

import java.util.List;

@Dao
public interface ContractorDao {
    @Insert
    long insert(Contractor contractor);

    @Update
    void update(Contractor contractor);

    @Delete
    void delete(Contractor contractor);

    @Query("SELECT * FROM contractors WHERE contractor_id = :id")
    LiveData<Contractor> getContractorById(long id);

    @Query("SELECT * FROM contractors ORDER BY name ASC")
    LiveData<List<Contractor>> getAllContractors();

    @Query("SELECT * FROM contractors WHERE specialization = :specialization ORDER BY name ASC")
    LiveData<List<Contractor>> getContractorsBySpecialization(String specialization);

    @Query("SELECT * FROM contractors WHERE name LIKE '%' || :searchQuery || '%' ORDER BY name ASC")
    LiveData<List<Contractor>> searchContractors(String searchQuery);
}
