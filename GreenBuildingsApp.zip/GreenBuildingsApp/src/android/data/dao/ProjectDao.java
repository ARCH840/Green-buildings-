package com.constructionmanager.app.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.constructionmanager.app.data.entities.Project;

import java.util.List;

@Dao
public interface ProjectDao {
    @Insert
    long insert(Project project);

    @Update
    void update(Project project);

    @Delete
    void delete(Project project);

    @Query("SELECT * FROM projects WHERE project_id = :id")
    LiveData<Project> getProjectById(long id);

    @Query("SELECT * FROM projects ORDER BY created_at DESC")
    LiveData<List<Project>> getAllProjects();

    @Query("SELECT * FROM projects WHERE status = :status ORDER BY created_at DESC")
    LiveData<List<Project>> getProjectsByStatus(String status);

    @Query("SELECT * FROM projects WHERE name LIKE '%' || :searchQuery || '%' ORDER BY created_at DESC")
    LiveData<List<Project>> searchProjects(String searchQuery);
}
