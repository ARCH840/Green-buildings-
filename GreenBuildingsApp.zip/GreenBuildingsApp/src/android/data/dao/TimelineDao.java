package com.constructionmanager.app.data.dao;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.constructionmanager.app.data.entities.Timeline;

import java.util.List;
import java.util.Date;

@Dao
public interface TimelineDao {
    @Insert
    long insert(Timeline timeline);

    @Update
    void update(Timeline timeline);

    @Delete
    void delete(Timeline timeline);

    @Query("SELECT * FROM timeline WHERE timeline_id = :id")
    LiveData<Timeline> getTimelineById(long id);

    @Query("SELECT * FROM timeline WHERE project_id = :projectId ORDER BY start_date ASC")
    LiveData<List<Timeline>> getTimelineByProject(long projectId);

    @Query("SELECT * FROM timeline WHERE status = :status ORDER BY start_date ASC")
    LiveData<List<Timeline>> getTimelineByStatus(String status);

    @Query("SELECT * FROM timeline WHERE start_date <= :date AND end_date >= :date ORDER BY start_date ASC")
    LiveData<List<Timeline>> getTimelineByDate(Date date);

    @Query("SELECT * FROM timeline WHERE title LIKE '%' || :searchQuery || '%' ORDER BY start_date ASC")
    LiveData<List<Timeline>> searchTimeline(String searchQuery);
}
