package com.constructionmanager.app.data.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.TypeConverters;

import com.constructionmanager.app.data.converters.DateConverter;

import java.util.Date;

@Entity(tableName = "notifications",
        foreignKeys = {
                @ForeignKey(entity = Project.class,
                        parentColumns = "project_id",
                        childColumns = "project_id",
                        onDelete = ForeignKey.CASCADE)
        },
        indices = {
                @Index("project_id")
        })
@TypeConverters(DateConverter.class)
public class Notification {
    @PrimaryKey(autoGenerate = true)
    private long notification_id;

    @ColumnInfo(name = "project_id")
    private long project_id;

    @ColumnInfo(name = "title")
    private String title;

    @ColumnInfo(name = "message")
    private String message;

    @ColumnInfo(name = "date")
    private Date date;

    @ColumnInfo(name = "priority")
    private String priority;

    @ColumnInfo(name = "is_read")
    private boolean is_read;

    @ColumnInfo(name = "created_at")
    private Date created_at;

    @ColumnInfo(name = "updated_at")
    private Date updated_at;

    // Constructors
    public Notification() {
    }

    public Notification(long project_id, String title, String message, Date date, String priority) {
        this.project_id = project_id;
        this.title = title;
        this.message = message;
        this.date = date;
        this.priority = priority;
        this.is_read = false;
        this.created_at = new Date();
        this.updated_at = new Date();
    }

    // Getters and Setters
    public long getNotification_id() {
        return notification_id;
    }

    public void setNotification_id(long notification_id) {
        this.notification_id = notification_id;
    }

    public long getProject_id() {
        return project_id;
    }

    public void setProject_id(long project_id) {
        this.project_id = project_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public String getPriority() {
        return priority;
    }

    public void setPriority(String priority) {
        this.priority = priority;
    }

    public boolean isIs_read() {
        return is_read;
    }

    public void setIs_read(boolean is_read) {
        this.is_read = is_read;
    }

    public Date getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Date created_at) {
        this.created_at = created_at;
    }

    public Date getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(Date updated_at) {
        this.updated_at = updated_at;
    }
}
