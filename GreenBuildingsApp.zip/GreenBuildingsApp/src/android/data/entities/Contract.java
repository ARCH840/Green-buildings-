package com.constructionmanager.app.data.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.TypeConverters;

import com.constructionmanager.app.data.converters.DateConverter;

import java.util.Date;

@Entity(tableName = "contracts",
        foreignKeys = {
                @ForeignKey(entity = Project.class,
                        parentColumns = "project_id",
                        childColumns = "project_id",
                        onDelete = ForeignKey.CASCADE),
                @ForeignKey(entity = Contractor.class,
                        parentColumns = "contractor_id",
                        childColumns = "contractor_id",
                        onDelete = ForeignKey.RESTRICT)
        },
        indices = {
                @Index("project_id"),
                @Index("contractor_id")
        })
@TypeConverters(DateConverter.class)
public class Contract {
    @PrimaryKey(autoGenerate = true)
    private long contract_id;

    @ColumnInfo(name = "project_id")
    private long project_id;

    @ColumnInfo(name = "contractor_id")
    private long contractor_id;

    @ColumnInfo(name = "title")
    private String title;

    @ColumnInfo(name = "description")
    private String description;

    @ColumnInfo(name = "start_date")
    private Date start_date;

    @ColumnInfo(name = "end_date")
    private Date end_date;

    @ColumnInfo(name = "contract_amount")
    private double contract_amount;

    @ColumnInfo(name = "payment_terms")
    private String payment_terms;

    @ColumnInfo(name = "status")
    private String status;

    @ColumnInfo(name = "created_at")
    private Date created_at;

    @ColumnInfo(name = "updated_at")
    private Date updated_at;

    // Constructors
    public Contract() {
    }

    public Contract(long project_id, long contractor_id, String title, String description, 
                   Date start_date, Date end_date, double contract_amount, 
                   String payment_terms, String status) {
        this.project_id = project_id;
        this.contractor_id = contractor_id;
        this.title = title;
        this.description = description;
        this.start_date = start_date;
        this.end_date = end_date;
        this.contract_amount = contract_amount;
        this.payment_terms = payment_terms;
        this.status = status;
        this.created_at = new Date();
        this.updated_at = new Date();
    }

    // Getters and Setters
    public long getContract_id() {
        return contract_id;
    }

    public void setContract_id(long contract_id) {
        this.contract_id = contract_id;
    }

    public long getProject_id() {
        return project_id;
    }

    public void setProject_id(long project_id) {
        this.project_id = project_id;
    }

    public long getContractor_id() {
        return contractor_id;
    }

    public void setContractor_id(long contractor_id) {
        this.contractor_id = contractor_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Date getStart_date() {
        return start_date;
    }

    public void setStart_date(Date start_date) {
        this.start_date = start_date;
    }

    public Date getEnd_date() {
        return end_date;
    }

    public void setEnd_date(Date end_date) {
        this.end_date = end_date;
    }

    public double getContract_amount() {
        return contract_amount;
    }

    public void setContract_amount(double contract_amount) {
        this.contract_amount = contract_amount;
    }

    public String getPayment_terms() {
        return payment_terms;
    }

    public void setPayment_terms(String payment_terms) {
        this.payment_terms = payment_terms;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Date created_at) {
        this.created_at = created_at;
    }

    public Date getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(Date updated_at) {
        this.updated_at = updated_at;
    }
}
