package com.constructionmanager.app.data.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;
import androidx.room.TypeConverters;

import com.constructionmanager.app.data.converters.DateConverter;

import java.util.Date;

@Entity(tableName = "projects")
@TypeConverters(DateConverter.class)
public class Project {
    @PrimaryKey(autoGenerate = true)
    private long project_id;

    @ColumnInfo(name = "name")
    private String name;

    @ColumnInfo(name = "description")
    private String description;

    @ColumnInfo(name = "location")
    private String location;

    @ColumnInfo(name = "start_date")
    private Date start_date;

    @ColumnInfo(name = "end_date")
    private Date end_date;

    @ColumnInfo(name = "budget")
    private double budget;

    @ColumnInfo(name = "status")
    private String status;

    @ColumnInfo(name = "created_at")
    private Date created_at;

    @ColumnInfo(name = "updated_at")
    private Date updated_at;

    // Constructors
    public Project() {
    }

    public Project(String name, String description, String location, Date start_date, Date end_date, double budget, String status) {
        this.name = name;
        this.description = description;
        this.location = location;
        this.start_date = start_date;
        this.end_date = end_date;
        this.budget = budget;
        this.status = status;
        this.created_at = new Date();
        this.updated_at = new Date();
    }

    // Getters and Setters
    public long getProject_id() {
        return project_id;
    }

    public void setProject_id(long project_id) {
        this.project_id = project_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Date getStart_date() {
        return start_date;
    }

    public void setStart_date(Date start_date) {
        this.start_date = start_date;
    }

    public Date getEnd_date() {
        return end_date;
    }

    public void setEnd_date(Date end_date) {
        this.end_date = end_date;
    }

    public double getBudget() {
        return budget;
    }

    public void setBudget(double budget) {
        this.budget = budget;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Date created_at) {
        this.created_at = created_at;
    }

    public Date getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(Date updated_at) {
        this.updated_at = updated_at;
    }
}
