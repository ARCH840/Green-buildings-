package com.constructionmanager.app.data.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.TypeConverters;

import com.constructionmanager.app.data.converters.DateConverter;

import java.util.Date;

@Entity(tableName = "works",
        foreignKeys = {
                @ForeignKey(entity = Contract.class,
                        parentColumns = "contract_id",
                        childColumns = "contract_id",
                        onDelete = ForeignKey.CASCADE)
        },
        indices = {
                @Index("contract_id")
        })
@TypeConverters(DateConverter.class)
public class Work {
    @PrimaryKey(autoGenerate = true)
    private long work_id;

    @ColumnInfo(name = "contract_id")
    private long contract_id;

    @ColumnInfo(name = "description")
    private String description;

    @ColumnInfo(name = "unit")
    private String unit;

    @ColumnInfo(name = "quantity")
    private double quantity;

    @ColumnInfo(name = "unit_price")
    private double unit_price;

    @ColumnInfo(name = "total_price")
    private double total_price;

    @ColumnInfo(name = "created_at")
    private Date created_at;

    @ColumnInfo(name = "updated_at")
    private Date updated_at;

    // Constructors
    public Work() {
    }

    public Work(long contract_id, String description, String unit, double quantity, double unit_price) {
        this.contract_id = contract_id;
        this.description = description;
        this.unit = unit;
        this.quantity = quantity;
        this.unit_price = unit_price;
        this.total_price = quantity * unit_price;
        this.created_at = new Date();
        this.updated_at = new Date();
    }

    // Getters and Setters
    public long getWork_id() {
        return work_id;
    }

    public void setWork_id(long work_id) {
        this.work_id = work_id;
    }

    public long getContract_id() {
        return contract_id;
    }

    public void setContract_id(long contract_id) {
        this.contract_id = contract_id;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public double getQuantity() {
        return quantity;
    }

    public void setQuantity(double quantity) {
        this.quantity = quantity;
        this.total_price = quantity * this.unit_price;
    }

    public double getUnit_price() {
        return unit_price;
    }

    public void setUnit_price(double unit_price) {
        this.unit_price = unit_price;
        this.total_price = this.quantity * unit_price;
    }

    public double getTotal_price() {
        return total_price;
    }

    public void setTotal_price(double total_price) {
        this.total_price = total_price;
    }

    public Date getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Date created_at) {
        this.created_at = created_at;
    }

    public Date getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(Date updated_at) {
        this.updated_at = updated_at;
    }
}
