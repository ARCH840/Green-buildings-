package com.constructionmanager.app.data.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.TypeConverters;

import com.constructionmanager.app.data.converters.DateConverter;

import java.util.Date;

@Entity(tableName = "work_progress",
        foreignKeys = {
                @ForeignKey(entity = Work.class,
                        parentColumns = "work_id",
                        childColumns = "work_id",
                        onDelete = ForeignKey.CASCADE)
        },
        indices = {
                @Index("work_id")
        })
@TypeConverters(DateConverter.class)
public class WorkProgress {
    @PrimaryKey(autoGenerate = true)
    private long progress_id;

    @ColumnInfo(name = "work_id")
    private long work_id;

    @ColumnInfo(name = "date")
    private Date date;

    @ColumnInfo(name = "quantity_completed")
    private double quantity_completed;

    @ColumnInfo(name = "notes")
    private String notes;

    @ColumnInfo(name = "created_at")
    private Date created_at;

    @ColumnInfo(name = "updated_at")
    private Date updated_at;

    // Constructors
    public WorkProgress() {
    }

    public WorkProgress(long work_id, Date date, double quantity_completed, String notes) {
        this.work_id = work_id;
        this.date = date;
        this.quantity_completed = quantity_completed;
        this.notes = notes;
        this.created_at = new Date();
        this.updated_at = new Date();
    }

    // Getters and Setters
    public long getProgress_id() {
        return progress_id;
    }

    public void setProgress_id(long progress_id) {
        this.progress_id = progress_id;
    }

    public long getWork_id() {
        return work_id;
    }

    public void setWork_id(long work_id) {
        this.work_id = work_id;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public double getQuantity_completed() {
        return quantity_completed;
    }

    public void setQuantity_completed(double quantity_completed) {
        this.quantity_completed = quantity_completed;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Date getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Date created_at) {
        this.created_at = created_at;
    }

    public Date getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(Date updated_at) {
        this.updated_at = updated_at;
    }
}
