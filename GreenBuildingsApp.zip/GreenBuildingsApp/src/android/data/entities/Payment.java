package com.constructionmanager.app.data.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.TypeConverters;

import com.constructionmanager.app.data.converters.DateConverter;

import java.util.Date;

@Entity(tableName = "payments",
        foreignKeys = {
                @ForeignKey(entity = Invoice.class,
                        parentColumns = "invoice_id",
                        childColumns = "invoice_id",
                        onDelete = ForeignKey.CASCADE)
        },
        indices = {
                @Index("invoice_id")
        })
@TypeConverters(DateConverter.class)
public class Payment {
    @PrimaryKey(autoGenerate = true)
    private long payment_id;

    @ColumnInfo(name = "invoice_id")
    private long invoice_id;

    @ColumnInfo(name = "amount")
    private double amount;

    @ColumnInfo(name = "payment_date")
    private Date payment_date;

    @ColumnInfo(name = "payment_method")
    private String payment_method;

    @ColumnInfo(name = "reference_number")
    private String reference_number;

    @ColumnInfo(name = "notes")
    private String notes;

    @ColumnInfo(name = "created_at")
    private Date created_at;

    @ColumnInfo(name = "updated_at")
    private Date updated_at;

    // Constructors
    public Payment() {
    }

    public Payment(long invoice_id, double amount, Date payment_date, String payment_method, 
                  String reference_number, String notes) {
        this.invoice_id = invoice_id;
        this.amount = amount;
        this.payment_date = payment_date;
        this.payment_method = payment_method;
        this.reference_number = reference_number;
        this.notes = notes;
        this.created_at = new Date();
        this.updated_at = new Date();
    }

    // Getters and Setters
    public long getPayment_id() {
        return payment_id;
    }

    public void setPayment_id(long payment_id) {
        this.payment_id = payment_id;
    }

    public long getInvoice_id() {
        return invoice_id;
    }

    public void setInvoice_id(long invoice_id) {
        this.invoice_id = invoice_id;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getPayment_date() {
        return payment_date;
    }

    public void setPayment_date(Date payment_date) {
        this.payment_date = payment_date;
    }

    public String getPayment_method() {
        return payment_method;
    }

    public void setPayment_method(String payment_method) {
        this.payment_method = payment_method;
    }

    public String getReference_number() {
        return reference_number;
    }

    public void setReference_number(String reference_number) {
        this.reference_number = reference_number;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public Date getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Date created_at) {
        this.created_at = created_at;
    }

    public Date getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(Date updated_at) {
        this.updated_at = updated_at;
    }
}
