package com.constructionmanager.app.data.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.TypeConverters;

import com.constructionmanager.app.data.converters.DateConverter;

import java.util.Date;

@Entity(tableName = "invoices",
        foreignKeys = {
                @ForeignKey(entity = Contract.class,
                        parentColumns = "contract_id",
                        childColumns = "contract_id",
                        onDelete = ForeignKey.CASCADE)
        },
        indices = {
                @Index("contract_id")
        })
@TypeConverters(DateConverter.class)
public class Invoice {
    @PrimaryKey(autoGenerate = true)
    private long invoice_id;

    @ColumnInfo(name = "contract_id")
    private long contract_id;

    @ColumnInfo(name = "invoice_number")
    private String invoice_number;

    @ColumnInfo(name = "date")
    private Date date;

    @ColumnInfo(name = "amount")
    private double amount;

    @ColumnInfo(name = "description")
    private String description;

    @ColumnInfo(name = "status")
    private String status;

    @ColumnInfo(name = "payment_date")
    private Date payment_date;

    @ColumnInfo(name = "created_at")
    private Date created_at;

    @ColumnInfo(name = "updated_at")
    private Date updated_at;

    // Constructors
    public Invoice() {
    }

    public Invoice(long contract_id, String invoice_number, Date date, double amount, 
                  String description, String status, Date payment_date) {
        this.contract_id = contract_id;
        this.invoice_number = invoice_number;
        this.date = date;
        this.amount = amount;
        this.description = description;
        this.status = status;
        this.payment_date = payment_date;
        this.created_at = new Date();
        this.updated_at = new Date();
    }

    // Getters and Setters
    public long getInvoice_id() {
        return invoice_id;
    }

    public void setInvoice_id(long invoice_id) {
        this.invoice_id = invoice_id;
    }

    public long getContract_id() {
        return contract_id;
    }

    public void setContract_id(long contract_id) {
        this.contract_id = contract_id;
    }

    public String getInvoice_number() {
        return invoice_number;
    }

    public void setInvoice_number(String invoice_number) {
        this.invoice_number = invoice_number;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getPayment_date() {
        return payment_date;
    }

    public void setPayment_date(Date payment_date) {
        this.payment_date = payment_date;
    }

    public Date getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Date created_at) {
        this.created_at = created_at;
    }

    public Date getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(Date updated_at) {
        this.updated_at = updated_at;
    }
}
