package com.constructionmanager.app.data.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;
import androidx.room.TypeConverters;

import com.constructionmanager.app.data.converters.DateConverter;

import java.util.Date;

@Entity(tableName = "contractors")
@TypeConverters(DateConverter.class)
public class Contractor {
    @PrimaryKey(autoGenerate = true)
    private long contractor_id;

    @ColumnInfo(name = "name")
    private String name;

    @ColumnInfo(name = "contact_person")
    private String contact_person;

    @ColumnInfo(name = "phone")
    private String phone;

    @ColumnInfo(name = "email")
    private String email;

    @ColumnInfo(name = "address")
    private String address;

    @ColumnInfo(name = "specialization")
    private String specialization;

    @ColumnInfo(name = "created_at")
    private Date created_at;

    @ColumnInfo(name = "updated_at")
    private Date updated_at;

    // Constructors
    public Contractor() {
    }

    public Contractor(String name, String contact_person, String phone, String email, String address, String specialization) {
        this.name = name;
        this.contact_person = contact_person;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.specialization = specialization;
        this.created_at = new Date();
        this.updated_at = new Date();
    }

    // Getters and Setters
    public long getContractor_id() {
        return contractor_id;
    }

    public void setContractor_id(long contractor_id) {
        this.contractor_id = contractor_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact_person() {
        return contact_person;
    }

    public void setContact_person(String contact_person) {
        this.contact_person = contact_person;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public Date getCreated_at() {
        return created_at;
    }

    public void setCreated_at(Date created_at) {
        this.created_at = created_at;
    }

    public Date getUpdated_at() {
        return updated_at;
    }

    public void setUpdated_at(Date updated_at) {
        this.updated_at = updated_at;
    }
}
