package com.constructionmanager.app.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.constructionmanager.app.data.entities.Resource;
import com.constructionmanager.app.repositories.ResourceRepository;

import java.util.List;

public class ResourceViewModel extends AndroidViewModel {
    private ResourceRepository repository;

    public ResourceViewModel(Application application) {
        super(application);
        repository = new ResourceRepository(application);
    }

    public LiveData<Resource> getResourceById(long id) {
        return repository.getResourceById(id);
    }

    public LiveData<List<Resource>> getResourcesByProject(long projectId) {
        return repository.getResourcesByProject(projectId);
    }

    public LiveData<List<Resource>> getResourcesByType(String type) {
        return repository.getResourcesByType(type);
    }

    public LiveData<Double> getTotalResourceCostByProject(long projectId) {
        return repository.getTotalResourceCostByProject(projectId);
    }

    public LiveData<List<Resource>> searchResources(String searchQuery) {
        return repository.searchResources(searchQuery);
    }

    public void insert(Resource resource) {
        repository.insert(resource);
    }

    public void update(Resource resource) {
        repository.update(resource);
    }

    public void delete(Resource resource) {
        repository.delete(resource);
    }
}
