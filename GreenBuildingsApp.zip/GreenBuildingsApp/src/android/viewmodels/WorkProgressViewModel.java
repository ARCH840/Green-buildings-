package com.constructionmanager.app.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.constructionmanager.app.data.entities.WorkProgress;
import com.constructionmanager.app.repositories.WorkProgressRepository;

import java.util.List;
import java.util.Date;

public class WorkProgressViewModel extends AndroidViewModel {
    private WorkProgressRepository repository;

    public WorkProgressViewModel(Application application) {
        super(application);
        repository = new WorkProgressRepository(application);
    }

    public LiveData<WorkProgress> getWorkProgressById(long id) {
        return repository.getWorkProgressById(id);
    }

    public LiveData<List<WorkProgress>> getWorkProgressByWork(long workId) {
        return repository.getWorkProgressByWork(workId);
    }

    public LiveData<Double> getTotalCompletedQuantityByWork(long workId) {
        return repository.getTotalCompletedQuantityByWork(workId);
    }

    public LiveData<List<WorkProgress>> getWorkProgressByDateRange(Date startDate, Date endDate) {
        return repository.getWorkProgressByDateRange(startDate, endDate);
    }

    public void insert(WorkProgress workProgress) {
        repository.insert(workProgress);
    }

    public void update(WorkProgress workProgress) {
        repository.update(workProgress);
    }

    public void delete(WorkProgress workProgress) {
        repository.delete(workProgress);
    }
}
