package com.constructionmanager.app.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.constructionmanager.app.data.entities.Invoice;
import com.constructionmanager.app.repositories.InvoiceRepository;

import java.util.List;
import java.util.Date;

public class InvoiceViewModel extends AndroidViewModel {
    private InvoiceRepository repository;

    public InvoiceViewModel(Application application) {
        super(application);
        repository = new InvoiceRepository(application);
    }

    public LiveData<Invoice> getInvoiceById(long id) {
        return repository.getInvoiceById(id);
    }

    public LiveData<List<Invoice>> getInvoicesByContract(long contractId) {
        return repository.getInvoicesByContract(contractId);
    }

    public LiveData<List<Invoice>> getInvoicesByStatus(String status) {
        return repository.getInvoicesByStatus(status);
    }

    public LiveData<Double> getTotalInvoiceAmountByContract(long contractId) {
        return repository.getTotalInvoiceAmountByContract(contractId);
    }

    public LiveData<List<Invoice>> getInvoicesByDateRange(Date startDate, Date endDate) {
        return repository.getInvoicesByDateRange(startDate, endDate);
    }

    public void insert(Invoice invoice) {
        repository.insert(invoice);
    }

    public void update(Invoice invoice) {
        repository.update(invoice);
    }

    public void delete(Invoice invoice) {
        repository.delete(invoice);
    }
}
