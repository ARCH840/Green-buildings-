package com.constructionmanager.app.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.constructionmanager.app.data.entities.Payment;
import com.constructionmanager.app.repositories.PaymentRepository;

import java.util.List;
import java.util.Date;

public class PaymentViewModel extends AndroidViewModel {
    private PaymentRepository repository;

    public PaymentViewModel(Application application) {
        super(application);
        repository = new PaymentRepository(application);
    }

    public LiveData<Payment> getPaymentById(long id) {
        return repository.getPaymentById(id);
    }

    public LiveData<List<Payment>> getPaymentsByInvoice(long invoiceId) {
        return repository.getPaymentsByInvoice(invoiceId);
    }

    public LiveData<Double> getTotalPaymentAmountByInvoice(long invoiceId) {
        return repository.getTotalPaymentAmountByInvoice(invoiceId);
    }

    public LiveData<List<Payment>> getPaymentsByDateRange(Date startDate, Date endDate) {
        return repository.getPaymentsByDateRange(startDate, endDate);
    }

    public void insert(Payment payment) {
        repository.insert(payment);
    }

    public void update(Payment payment) {
        repository.update(payment);
    }

    public void delete(Payment payment) {
        repository.delete(payment);
    }
}
