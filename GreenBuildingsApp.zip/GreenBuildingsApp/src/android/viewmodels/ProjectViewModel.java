package com.constructionmanager.app.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.constructionmanager.app.data.entities.Project;
import com.constructionmanager.app.repositories.ProjectRepository;

import java.util.List;

public class ProjectViewModel extends AndroidViewModel {
    private ProjectRepository repository;
    private LiveData<List<Project>> allProjects;

    public ProjectViewModel(Application application) {
        super(application);
        repository = new ProjectRepository(application);
        allProjects = repository.getAllProjects();
    }

    public LiveData<List<Project>> getAllProjects() {
        return allProjects;
    }

    public LiveData<Project> getProjectById(long id) {
        return repository.getProjectById(id);
    }

    public LiveData<List<Project>> getProjectsByStatus(String status) {
        return repository.getProjectsByStatus(status);
    }

    public LiveData<List<Project>> searchProjects(String searchQuery) {
        return repository.searchProjects(searchQuery);
    }

    public void insert(Project project) {
        repository.insert(project);
    }

    public void update(Project project) {
        repository.update(project);
    }

    public void delete(Project project) {
        repository.delete(project);
    }
}
