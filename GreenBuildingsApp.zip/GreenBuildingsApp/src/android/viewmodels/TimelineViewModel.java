package com.constructionmanager.app.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.constructionmanager.app.data.entities.Timeline;
import com.constructionmanager.app.repositories.TimelineRepository;

import java.util.List;
import java.util.Date;

public class TimelineViewModel extends AndroidViewModel {
    private TimelineRepository repository;

    public TimelineViewModel(Application application) {
        super(application);
        repository = new TimelineRepository(application);
    }

    public LiveData<Timeline> getTimelineById(long id) {
        return repository.getTimelineById(id);
    }

    public LiveData<List<Timeline>> getTimelineByProject(long projectId) {
        return repository.getTimelineByProject(projectId);
    }

    public LiveData<List<Timeline>> getTimelineByStatus(String status) {
        return repository.getTimelineByStatus(status);
    }

    public LiveData<List<Timeline>> getTimelineByDate(Date date) {
        return repository.getTimelineByDate(date);
    }

    public LiveData<List<Timeline>> searchTimeline(String searchQuery) {
        return repository.searchTimeline(searchQuery);
    }

    public void insert(Timeline timeline) {
        repository.insert(timeline);
    }

    public void update(Timeline timeline) {
        repository.update(timeline);
    }

    public void delete(Timeline timeline) {
        repository.delete(timeline);
    }
}
