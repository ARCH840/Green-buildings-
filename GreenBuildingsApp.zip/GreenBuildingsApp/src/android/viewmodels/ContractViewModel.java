package com.constructionmanager.app.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.constructionmanager.app.data.entities.Contract;
import com.constructionmanager.app.repositories.ContractRepository;

import java.util.List;

public class ContractViewModel extends AndroidViewModel {
    private ContractRepository repository;

    public ContractViewModel(Application application) {
        super(application);
        repository = new ContractRepository(application);
    }

    public LiveData<Contract> getContractById(long id) {
        return repository.getContractById(id);
    }

    public LiveData<List<Contract>> getContractsByProject(long projectId) {
        return repository.getContractsByProject(projectId);
    }

    public LiveData<List<Contract>> getContractsByContractor(long contractorId) {
        return repository.getContractsByContractor(contractorId);
    }

    public LiveData<List<Contract>> getContractsByStatus(String status) {
        return repository.getContractsByStatus(status);
    }

    public LiveData<List<Contract>> searchContracts(String searchQuery) {
        return repository.searchContracts(searchQuery);
    }

    public void insert(Contract contract) {
        repository.insert(contract);
    }

    public void update(Contract contract) {
        repository.update(contract);
    }

    public void delete(Contract contract) {
        repository.delete(contract);
    }
}
