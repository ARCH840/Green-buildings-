package com.constructionmanager.app.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.constructionmanager.app.data.entities.Notification;
import com.constructionmanager.app.repositories.NotificationRepository;

import java.util.List;
import java.util.Date;

public class NotificationViewModel extends AndroidViewModel {
    private NotificationRepository repository;

    public NotificationViewModel(Application application) {
        super(application);
        repository = new NotificationRepository(application);
    }

    public LiveData<Notification> getNotificationById(long id) {
        return repository.getNotificationById(id);
    }

    public LiveData<List<Notification>> getNotificationsByProject(long projectId) {
        return repository.getNotificationsByProject(projectId);
    }

    public LiveData<List<Notification>> getUnreadNotifications() {
        return repository.getUnreadNotifications();
    }

    public LiveData<List<Notification>> getNotificationsByPriority(String priority) {
        return repository.getNotificationsByPriority(priority);
    }

    public LiveData<List<Notification>> getNotificationsByDateRange(Date startDate, Date endDate) {
        return repository.getNotificationsByDateRange(startDate, endDate);
    }

    public void insert(Notification notification) {
        repository.insert(notification);
    }

    public void update(Notification notification) {
        repository.update(notification);
    }

    public void delete(Notification notification) {
        repository.delete(notification);
    }

    public void markNotificationAsRead(long id) {
        repository.markNotificationAsRead(id);
    }

    public void markAllProjectNotificationsAsRead(long projectId) {
        repository.markAllProjectNotificationsAsRead(projectId);
    }
}
