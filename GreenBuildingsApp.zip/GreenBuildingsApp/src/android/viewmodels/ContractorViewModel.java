package com.constructionmanager.app.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.constructionmanager.app.data.entities.Contractor;
import com.constructionmanager.app.repositories.ContractorRepository;

import java.util.List;

public class ContractorViewModel extends AndroidViewModel {
    private ContractorRepository repository;
    private LiveData<List<Contractor>> allContractors;

    public ContractorViewModel(Application application) {
        super(application);
        repository = new ContractorRepository(application);
        allContractors = repository.getAllContractors();
    }

    public LiveData<List<Contractor>> getAllContractors() {
        return allContractors;
    }

    public LiveData<Contractor> getContractorById(long id) {
        return repository.getContractorById(id);
    }

    public LiveData<List<Contractor>> getContractorsBySpecialization(String specialization) {
        return repository.getContractorsBySpecialization(specialization);
    }

    public LiveData<List<Contractor>> searchContractors(String searchQuery) {
        return repository.searchContractors(searchQuery);
    }

    public void insert(Contractor contractor) {
        repository.insert(contractor);
    }

    public void update(Contractor contractor) {
        repository.update(contractor);
    }

    public void delete(Contractor contractor) {
        repository.delete(contractor);
    }
}
