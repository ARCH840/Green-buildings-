package com.constructionmanager.app.viewmodels;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.constructionmanager.app.data.entities.Work;
import com.constructionmanager.app.repositories.WorkRepository;

import java.util.List;

public class WorkViewModel extends AndroidViewModel {
    private WorkRepository repository;

    public WorkViewModel(Application application) {
        super(application);
        repository = new WorkRepository(application);
    }

    public LiveData<Work> getWorkById(long id) {
        return repository.getWorkById(id);
    }

    public LiveData<List<Work>> getWorksByContract(long contractId) {
        return repository.getWorksByContract(contractId);
    }

    public LiveData<Double> getTotalWorkValueByContract(long contractId) {
        return repository.getTotalWorkValueByContract(contractId);
    }

    public LiveData<List<Work>> searchWorks(String searchQuery) {
        return repository.searchWorks(searchQuery);
    }

    public void insert(Work work) {
        repository.insert(work);
    }

    public void update(Work work) {
        repository.update(work);
    }

    public void delete(Work work) {
        repository.delete(work);
    }
}
