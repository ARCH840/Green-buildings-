package com.constructionmanager.app;

import android.app.Application;

import androidx.room.Room;

import com.constructionmanager.app.data.AppDatabase;

public class ConstructionManagerApp extends Application {

    private static ConstructionManagerApp instance;
    private AppDatabase database;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        
        // إنشاء قاعدة البيانات
        database = Room.databaseBuilder(getApplicationContext(),
                AppDatabase.class, "construction_manager_db")
                .fallbackToDestructiveMigration()
                .build();
    }

    public static ConstructionManagerApp getInstance() {
        return instance;
    }

    public AppDatabase getDatabase() {
        return database;
    }
}
