package com.constructionmanager.app.repositories;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.constructionmanager.app.ConstructionManagerApp;
import com.constructionmanager.app.data.AppDatabase;
import com.constructionmanager.app.data.dao.NotificationDao;
import com.constructionmanager.app.data.entities.Notification;

import java.util.List;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class NotificationRepository {
    private NotificationDao notificationDao;
    private ExecutorService executorService;

    public NotificationRepository(Application application) {
        AppDatabase database = ConstructionManagerApp.getInstance().getDatabase();
        notificationDao = database.notificationDao();
        executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<Notification> getNotificationById(long id) {
        return notificationDao.getNotificationById(id);
    }

    public LiveData<List<Notification>> getNotificationsByProject(long projectId) {
        return notificationDao.getNotificationsByProject(projectId);
    }

    public LiveData<List<Notification>> getUnreadNotifications() {
        return notificationDao.getUnreadNotifications();
    }

    public LiveData<List<Notification>> getNotificationsByPriority(String priority) {
        return notificationDao.getNotificationsByPriority(priority);
    }

    public LiveData<List<Notification>> getNotificationsByDateRange(Date startDate, Date endDate) {
        return notificationDao.getNotificationsByDateRange(startDate, endDate);
    }

    public void insert(Notification notification) {
        executorService.execute(() -> {
            notificationDao.insert(notification);
        });
    }

    public void update(Notification notification) {
        executorService.execute(() -> {
            notificationDao.update(notification);
        });
    }

    public void delete(Notification notification) {
        executorService.execute(() -> {
            notificationDao.delete(notification);
        });
    }

    public void markNotificationAsRead(long id) {
        executorService.execute(() -> {
            notificationDao.markNotificationAsRead(id);
        });
    }

    public void markAllProjectNotificationsAsRead(long projectId) {
        executorService.execute(() -> {
            notificationDao.markAllProjectNotificationsAsRead(projectId);
        });
    }
}
