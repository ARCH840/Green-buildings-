package com.constructionmanager.app.repositories;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.constructionmanager.app.ConstructionManagerApp;
import com.constructionmanager.app.data.AppDatabase;
import com.constructionmanager.app.data.dao.TimelineDao;
import com.constructionmanager.app.data.entities.Timeline;

import java.util.List;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TimelineRepository {
    private TimelineDao timelineDao;
    private ExecutorService executorService;

    public TimelineRepository(Application application) {
        AppDatabase database = ConstructionManagerApp.getInstance().getDatabase();
        timelineDao = database.timelineDao();
        executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<Timeline> getTimelineById(long id) {
        return timelineDao.getTimelineById(id);
    }

    public LiveData<List<Timeline>> getTimelineByProject(long projectId) {
        return timelineDao.getTimelineByProject(projectId);
    }

    public LiveData<List<Timeline>> getTimelineByStatus(String status) {
        return timelineDao.getTimelineByStatus(status);
    }

    public LiveData<List<Timeline>> getTimelineByDate(Date date) {
        return timelineDao.getTimelineByDate(date);
    }

    public LiveData<List<Timeline>> searchTimeline(String searchQuery) {
        return timelineDao.searchTimeline(searchQuery);
    }

    public void insert(Timeline timeline) {
        executorService.execute(() -> {
            timelineDao.insert(timeline);
        });
    }

    public void update(Timeline timeline) {
        executorService.execute(() -> {
            timelineDao.update(timeline);
        });
    }

    public void delete(Timeline timeline) {
        executorService.execute(() -> {
            timelineDao.delete(timeline);
        });
    }
}
