package com.constructionmanager.app.repositories;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.constructionmanager.app.ConstructionManagerApp;
import com.constructionmanager.app.data.AppDatabase;
import com.constructionmanager.app.data.dao.ContractorDao;
import com.constructionmanager.app.data.entities.Contractor;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ContractorRepository {
    private ContractorDao contractorDao;
    private LiveData<List<Contractor>> allContractors;
    private ExecutorService executorService;

    public ContractorRepository(Application application) {
        AppDatabase database = ConstructionManagerApp.getInstance().getDatabase();
        contractorDao = database.contractorDao();
        allContractors = contractorDao.getAllContractors();
        executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<List<Contractor>> getAllContractors() {
        return allContractors;
    }

    public LiveData<Contractor> getContractorById(long id) {
        return contractorDao.getContractorById(id);
    }

    public LiveData<List<Contractor>> getContractorsBySpecialization(String specialization) {
        return contractorDao.getContractorsBySpecialization(specialization);
    }

    public LiveData<List<Contractor>> searchContractors(String searchQuery) {
        return contractorDao.searchContractors(searchQuery);
    }

    public void insert(Contractor contractor) {
        executorService.execute(() -> {
            contractorDao.insert(contractor);
        });
    }

    public void update(Contractor contractor) {
        executorService.execute(() -> {
            contractorDao.update(contractor);
        });
    }

    public void delete(Contractor contractor) {
        executorService.execute(() -> {
            contractorDao.delete(contractor);
        });
    }
}
