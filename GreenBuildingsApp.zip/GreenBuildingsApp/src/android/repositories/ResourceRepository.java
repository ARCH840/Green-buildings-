package com.constructionmanager.app.repositories;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.constructionmanager.app.ConstructionManagerApp;
import com.constructionmanager.app.data.AppDatabase;
import com.constructionmanager.app.data.dao.ResourceDao;
import com.constructionmanager.app.data.entities.Resource;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ResourceRepository {
    private ResourceDao resourceDao;
    private ExecutorService executorService;

    public ResourceRepository(Application application) {
        AppDatabase database = ConstructionManagerApp.getInstance().getDatabase();
        resourceDao = database.resourceDao();
        executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<Resource> getResourceById(long id) {
        return resourceDao.getResourceById(id);
    }

    public LiveData<List<Resource>> getResourcesByProject(long projectId) {
        return resourceDao.getResourcesByProject(projectId);
    }

    public LiveData<List<Resource>> getResourcesByType(String type) {
        return resourceDao.getResourcesByType(type);
    }

    public LiveData<Double> getTotalResourceCostByProject(long projectId) {
        return resourceDao.getTotalResourceCostByProject(projectId);
    }

    public LiveData<List<Resource>> searchResources(String searchQuery) {
        return resourceDao.searchResources(searchQuery);
    }

    public void insert(Resource resource) {
        executorService.execute(() -> {
            resourceDao.insert(resource);
        });
    }

    public void update(Resource resource) {
        executorService.execute(() -> {
            resourceDao.update(resource);
        });
    }

    public void delete(Resource resource) {
        executorService.execute(() -> {
            resourceDao.delete(resource);
        });
    }
}
