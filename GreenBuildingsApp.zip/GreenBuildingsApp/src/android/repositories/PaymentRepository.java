package com.constructionmanager.app.repositories;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.constructionmanager.app.ConstructionManagerApp;
import com.constructionmanager.app.data.AppDatabase;
import com.constructionmanager.app.data.dao.PaymentDao;
import com.constructionmanager.app.data.entities.Payment;

import java.util.List;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class PaymentRepository {
    private PaymentDao paymentDao;
    private ExecutorService executorService;

    public PaymentRepository(Application application) {
        AppDatabase database = ConstructionManagerApp.getInstance().getDatabase();
        paymentDao = database.paymentDao();
        executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<Payment> getPaymentById(long id) {
        return paymentDao.getPaymentById(id);
    }

    public LiveData<List<Payment>> getPaymentsByInvoice(long invoiceId) {
        return paymentDao.getPaymentsByInvoice(invoiceId);
    }

    public LiveData<Double> getTotalPaymentAmountByInvoice(long invoiceId) {
        return paymentDao.getTotalPaymentAmountByInvoice(invoiceId);
    }

    public LiveData<List<Payment>> getPaymentsByDateRange(Date startDate, Date endDate) {
        return paymentDao.getPaymentsByDateRange(startDate, endDate);
    }

    public void insert(Payment payment) {
        executorService.execute(() -> {
            paymentDao.insert(payment);
        });
    }

    public void update(Payment payment) {
        executorService.execute(() -> {
            paymentDao.update(payment);
        });
    }

    public void delete(Payment payment) {
        executorService.execute(() -> {
            paymentDao.delete(payment);
        });
    }
}
