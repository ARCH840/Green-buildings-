package com.constructionmanager.app.repositories;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.constructionmanager.app.ConstructionManagerApp;
import com.constructionmanager.app.data.AppDatabase;
import com.constructionmanager.app.data.dao.WorkProgressDao;
import com.constructionmanager.app.data.entities.WorkProgress;

import java.util.List;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WorkProgressRepository {
    private WorkProgressDao workProgressDao;
    private ExecutorService executorService;

    public WorkProgressRepository(Application application) {
        AppDatabase database = ConstructionManagerApp.getInstance().getDatabase();
        workProgressDao = database.workProgressDao();
        executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<WorkProgress> getWorkProgressById(long id) {
        return workProgressDao.getWorkProgressById(id);
    }

    public LiveData<List<WorkProgress>> getWorkProgressByWork(long workId) {
        return workProgressDao.getWorkProgressByWork(workId);
    }

    public LiveData<Double> getTotalCompletedQuantityByWork(long workId) {
        return workProgressDao.getTotalCompletedQuantityByWork(workId);
    }

    public LiveData<List<WorkProgress>> getWorkProgressByDateRange(Date startDate, Date endDate) {
        return workProgressDao.getWorkProgressByDateRange(startDate, endDate);
    }

    public void insert(WorkProgress workProgress) {
        executorService.execute(() -> {
            workProgressDao.insert(workProgress);
        });
    }

    public void update(WorkProgress workProgress) {
        executorService.execute(() -> {
            workProgressDao.update(workProgress);
        });
    }

    public void delete(WorkProgress workProgress) {
        executorService.execute(() -> {
            workProgressDao.delete(workProgress);
        });
    }
}
