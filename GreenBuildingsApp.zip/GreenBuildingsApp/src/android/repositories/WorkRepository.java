package com.constructionmanager.app.repositories;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.constructionmanager.app.ConstructionManagerApp;
import com.constructionmanager.app.data.AppDatabase;
import com.constructionmanager.app.data.dao.WorkDao;
import com.constructionmanager.app.data.entities.Work;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class WorkRepository {
    private WorkDao workDao;
    private ExecutorService executorService;

    public WorkRepository(Application application) {
        AppDatabase database = ConstructionManagerApp.getInstance().getDatabase();
        workDao = database.workDao();
        executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<Work> getWorkById(long id) {
        return workDao.getWorkById(id);
    }

    public LiveData<List<Work>> getWorksByContract(long contractId) {
        return workDao.getWorksByContract(contractId);
    }

    public LiveData<Double> getTotalWorkValueByContract(long contractId) {
        return workDao.getTotalWorkValueByContract(contractId);
    }

    public LiveData<List<Work>> searchWorks(String searchQuery) {
        return workDao.searchWorks(searchQuery);
    }

    public void insert(Work work) {
        executorService.execute(() -> {
            workDao.insert(work);
        });
    }

    public void update(Work work) {
        executorService.execute(() -> {
            workDao.update(work);
        });
    }

    public void delete(Work work) {
        executorService.execute(() -> {
            workDao.delete(work);
        });
    }
}
