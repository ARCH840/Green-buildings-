package com.constructionmanager.app.repositories;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.constructionmanager.app.ConstructionManagerApp;
import com.constructionmanager.app.data.AppDatabase;
import com.constructionmanager.app.data.dao.ContractDao;
import com.constructionmanager.app.data.entities.Contract;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ContractRepository {
    private ContractDao contractDao;
    private ExecutorService executorService;

    public ContractRepository(Application application) {
        AppDatabase database = ConstructionManagerApp.getInstance().getDatabase();
        contractDao = database.contractDao();
        executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<Contract> getContractById(long id) {
        return contractDao.getContractById(id);
    }

    public LiveData<List<Contract>> getContractsByProject(long projectId) {
        return contractDao.getContractsByProject(projectId);
    }

    public LiveData<List<Contract>> getContractsByContractor(long contractorId) {
        return contractDao.getContractsByContractor(contractorId);
    }

    public LiveData<List<Contract>> getContractsByStatus(String status) {
        return contractDao.getContractsByStatus(status);
    }

    public LiveData<List<Contract>> searchContracts(String searchQuery) {
        return contractDao.searchContracts(searchQuery);
    }

    public void insert(Contract contract) {
        executorService.execute(() -> {
            contractDao.insert(contract);
        });
    }

    public void update(Contract contract) {
        executorService.execute(() -> {
            contractDao.update(contract);
        });
    }

    public void delete(Contract contract) {
        executorService.execute(() -> {
            contractDao.delete(contract);
        });
    }
}
