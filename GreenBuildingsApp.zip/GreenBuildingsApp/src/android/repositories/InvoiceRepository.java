package com.constructionmanager.app.repositories;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.constructionmanager.app.ConstructionManagerApp;
import com.constructionmanager.app.data.AppDatabase;
import com.constructionmanager.app.data.dao.InvoiceDao;
import com.constructionmanager.app.data.entities.Invoice;

import java.util.List;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class InvoiceRepository {
    private InvoiceDao invoiceDao;
    private ExecutorService executorService;

    public InvoiceRepository(Application application) {
        AppDatabase database = ConstructionManagerApp.getInstance().getDatabase();
        invoiceDao = database.invoiceDao();
        executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<Invoice> getInvoiceById(long id) {
        return invoiceDao.getInvoiceById(id);
    }

    public LiveData<List<Invoice>> getInvoicesByContract(long contractId) {
        return invoiceDao.getInvoicesByContract(contractId);
    }

    public LiveData<List<Invoice>> getInvoicesByStatus(String status) {
        return invoiceDao.getInvoicesByStatus(status);
    }

    public LiveData<Double> getTotalInvoiceAmountByContract(long contractId) {
        return invoiceDao.getTotalInvoiceAmountByContract(contractId);
    }

    public LiveData<List<Invoice>> getInvoicesByDateRange(Date startDate, Date endDate) {
        return invoiceDao.getInvoicesByDateRange(startDate, endDate);
    }

    public void insert(Invoice invoice) {
        executorService.execute(() -> {
            invoiceDao.insert(invoice);
        });
    }

    public void update(Invoice invoice) {
        executorService.execute(() -> {
            invoiceDao.update(invoice);
        });
    }

    public void delete(Invoice invoice) {
        executorService.execute(() -> {
            invoiceDao.delete(invoice);
        });
    }
}
