package com.constructionmanager.app.repositories;

import android.app.Application;

import androidx.lifecycle.LiveData;

import com.constructionmanager.app.ConstructionManagerApp;
import com.constructionmanager.app.data.AppDatabase;
import com.constructionmanager.app.data.dao.ProjectDao;
import com.constructionmanager.app.data.entities.Project;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ProjectRepository {
    private ProjectDao projectDao;
    private LiveData<List<Project>> allProjects;
    private ExecutorService executorService;

    public ProjectRepository(Application application) {
        AppDatabase database = ConstructionManagerApp.getInstance().getDatabase();
        projectDao = database.projectDao();
        allProjects = projectDao.getAllProjects();
        executorService = Executors.newSingleThreadExecutor();
    }

    public LiveData<List<Project>> getAllProjects() {
        return allProjects;
    }

    public LiveData<Project> getProjectById(long id) {
        return projectDao.getProjectById(id);
    }

    public LiveData<List<Project>> getProjectsByStatus(String status) {
        return projectDao.getProjectsByStatus(status);
    }

    public LiveData<List<Project>> searchProjects(String searchQuery) {
        return projectDao.searchProjects(searchQuery);
    }

    public void insert(Project project) {
        executorService.execute(() -> {
            projectDao.insert(project);
        });
    }

    public void update(Project project) {
        executorService.execute(() -> {
            projectDao.update(project);
        });
    }

    public void delete(Project project) {
        executorService.execute(() -> {
            projectDao.delete(project);
        });
    }
}
